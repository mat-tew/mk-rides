# Contributing to MK RIDES

Thanks for your interest in building on MK RIDES. This is the initial
commit of the monorepo and contributions are welcome — please follow
the conventions below so reviews stay fast.

## Workflow

1. Fork the repository and create a topic branch.
2. Install workspace dependencies: `npm install`.
3. Make your change. Run `npm run lint && npm run typecheck` before
   pushing.
4. Open a pull request describing the change and linking any related
   issues.

## Commit messages

We use [Conventional Commits](https://www.conventionalcommits.org/):

```
feat(passenger): add ride tracking map
fix(api): clamp surge multiplier to city cap
docs(readme): document fare calculator
```

## Code style

- TypeScript everywhere. Avoid `any` — prefer `unknown` plus a type guard.
- Two-space indent, single quotes, trailing commas (see `.prettierrc.json`).
- All shared types live in `packages/shared-types`; do not redefine
  them in apps.

## Adding a workspace

New apps go under `apps/`, new services under `services/`, new shared
packages under `packages/`. Update the root `package.json` `workspaces`
field if you use a non-glob path.

## Secrets

Do not commit real credentials. Use the `.env.example` files as a
template and add new variables there with `replace-me` placeholders.