import { describe, expect, it } from 'vitest';

import { fareCalculator } from '../src/services/fareCalculator.js';

describe('fareCalculator', () => {
  it('returns at least the minimum fare for short trips', () => {
    const quote = fareCalculator.quote(
      { latitude: -1.286389, longitude: 36.817223 }, // Nairobi CBD
      { latitude: -1.290000, longitude: 36.820000 },
      'nairobi',
    );
    expect(quote.amountKsh).toBeGreaterThanOrEqual(150);
    expect(quote.currency).toBe('KES');
    expect(quote.distanceKm).toBeGreaterThan(0);
  });

  it('applies surge multiplier up to the city cap', () => {
    const base = fareCalculator.quote(
      { latitude: -1.286389, longitude: 36.817223 },
      { latitude: -1.350000, longitude: 36.850000 },
      'nairobi',
      1,
    );
    const surged = fareCalculator.quote(
      { latitude: -1.286389, longitude: 36.817223 },
      { latitude: -1.350000, longitude: 36.850000 },
      'nairobi',
      5, // capped at 2.5 for Nairobi
    );
    expect(surged.amountKsh).toBeLessThanOrEqual(Math.round(base.amountKsh * 2.5));
  });
});