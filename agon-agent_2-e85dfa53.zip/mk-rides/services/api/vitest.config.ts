import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    include: ['tests/**/*.test.ts'],
  },
  resolve: {
    alias: {
      '@': new URL('./src', import.meta.url).pathname,
      '@mk-rides/shared-types': new URL('../packages/shared-types/src', import.meta.url).pathname,
      '@mk-rides/shared-utils': new URL('../packages/shared-utils/src', import.meta.url).pathname,
    },
  },
});