import type { FastifyError, FastifyReply, FastifyRequest } from 'fastify';
import { ZodError } from 'zod';

import { logger } from '../utils/logger.js';

/**
 * Centralised error handler. Translates Zod validation errors into a
 * 400 with field details and obscures internal stack traces from
 * production clients.
 */
export async function errorHandler(
  err: FastifyError | ZodError | Error,
  req: FastifyRequest,
  reply: FastifyReply,
): Promise<void> {
  if (err instanceof ZodError) {
    return reply.code(400).send({
      error: 'ValidationError',
      issues: err.flatten().fieldErrors,
    });
  }

  const status = (err as FastifyError).statusCode ?? 500;
  if (status >= 500) {
    logger.error({ err, url: req.url, method: req.method }, 'Unhandled error');
  }

  return reply.code(status).send({
    error: err.name || 'Error',
    message: status >= 500 ? 'Internal server error' : err.message,
  });
}