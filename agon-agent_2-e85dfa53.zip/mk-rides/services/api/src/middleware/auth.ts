import type { FastifyReply, FastifyRequest } from 'fastify';

import type { Role } from '@mk-rides/shared-types';

export interface AuthContext {
  userId: string;
  role: Role;
}

/**
 * Verifies the bearer JWT and attaches the decoded auth context to
 * the request. Throws via Fastify's error machinery when missing or
 * invalid.
 */
export async function requireAuth(req: FastifyRequest, reply: FastifyReply): Promise<void> {
  try {
    await req.jwtVerify();
    const payload = req.user as { sub?: string; role?: Role } | undefined;
    if (!payload?.sub || !payload.role) {
      return reply.code(401).send({ error: 'Invalid token' });
    }
    (req as FastifyRequest & { auth: AuthContext }).auth = {
      userId: payload.sub,
      role: payload.role,
    };
  } catch {
    return reply.code(401).send({ error: 'Unauthorized' });
  }
}

export function requireRole(...roles: Role[]) {
  return async (req: FastifyRequest, reply: FastifyReply): Promise<void> => {
    await requireAuth(req, reply);
    const auth = (req as FastifyRequest & { auth?: AuthContext }).auth;
    if (!auth || !roles.includes(auth.role)) {
      return reply.code(403).send({ error: 'Forbidden' });
    }
  };
}