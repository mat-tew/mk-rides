import { PrismaClient } from '@prisma/client';

import { env } from './env.js';

/**
 * Single Prisma client instance. We disable query logs in production
 * and pretty-print them in development to keep the dev experience
 * readable.
 */
export const prisma = new PrismaClient({
  log: env.NODE_ENV === 'development' ? ['query', 'warn', 'error'] : ['warn', 'error'],
});

export async function disconnectPrisma(): Promise<void> {
  await prisma.$disconnect();
}