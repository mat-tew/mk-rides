import { z } from 'zod';

/**
 * Strongly-typed environment loader. Fails fast at boot if anything
 * required is missing or malformed. `.env.example` documents each
 * variable; values are provided by the deployment environment.
 */

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace']).default('info'),
  API_PORT: z.coerce.number().int().positive().default(4000),
  API_HOST: z.string().default('0.0.0.0'),

  DATABASE_URL: z.string().url(),

  JWT_SECRET: z.string().min(32, 'JWT_SECRET must be at least 32 chars'),
  JWT_EXPIRES_IN: z.string().default('15m'),
  REFRESH_TOKEN_EXPIRES_IN: z.string().default('30d'),

  CORS_ORIGINS: z.string().default('http://localhost:3000'),

  MPESA_ENVIRONMENT: z.enum(['sandbox', 'production']).default('sandbox'),
  MPESA_CONSUMER_KEY: z.string().default(''),
  MPESA_CONSUMER_SECRET: z.string().default(''),
  MPESA_SHORTCODE: z.string().default(''),
  MPESA_PASSKEY: z.string().default(''),
  MPESA_B2C_INITIATOR_NAME: z.string().default(''),
  MPESA_B2C_SECURITY_CREDENTIAL: z.string().default(''),
  MPESA_CALLBACK_URL: z.string().url().default('https://example.com/callback'),

  AT_API_KEY: z.string().default(''),
  AT_USERNAME: z.string().default('sandbox'),

  GOOGLE_MAPS_API_KEY: z.string().default(''),
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  // eslint-disable-next-line no-console
  console.error('❌ Invalid environment configuration:', parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const env = {
  NODE_ENV: parsed.data.NODE_ENV,
  LOG_LEVEL: parsed.data.LOG_LEVEL,
  PORT: parsed.data.API_PORT,
  HOST: parsed.data.API_HOST,
  DATABASE_URL: parsed.data.DATABASE_URL,
  JWT_SECRET: parsed.data.JWT_SECRET,
  JWT_EXPIRES_IN: parsed.data.JWT_EXPIRES_IN,
  REFRESH_TOKEN_EXPIRES_IN: parsed.data.REFRESH_TOKEN_EXPIRES_IN,
  CORS_ORIGINS: parsed.data.CORS_ORIGINS,
  MPESA: {
    ENVIRONMENT: parsed.data.MPESA_ENVIRONMENT,
    CONSUMER_KEY: parsed.data.MPESA_CONSUMER_KEY,
    CONSUMER_SECRET: parsed.data.MPESA_CONSUMER_SECRET,
    SHORTCODE: parsed.data.MPESA_SHORTCODE,
    PASSKEY: parsed.data.MPESA_PASSKEY,
    B2C_INITIATOR_NAME: parsed.data.MPESA_B2C_INITIATOR_NAME,
    B2C_SECURITY_CREDENTIAL: parsed.data.MPESA_B2C_SECURITY_CREDENTIAL,
    CALLBACK_URL: parsed.data.MPESA_CALLBACK_URL,
  },
  AT: {
    API_KEY: parsed.data.AT_API_KEY,
    USERNAME: parsed.data.AT_USERNAME,
  },
  GOOGLE_MAPS_API_KEY: parsed.data.GOOGLE_MAPS_API_KEY,
};

export type Env = typeof env;