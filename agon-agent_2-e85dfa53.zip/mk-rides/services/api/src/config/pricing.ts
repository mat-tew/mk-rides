import type { CityPricing } from '@mk-rides/shared-types';

/**
 * Pricing matrix in Kenyan Shillings. Tunable from the admin dashboard;
 * the initial commit ships sensible defaults for Nairobi, Mombasa and
 * Kisumu. Distances are in km, times in minutes.
 */
export const CITY_PRICING: Record<'nairobi' | 'mombasa' | 'kisumu', CityPricing> = {
  nairobi: {
    baseFareKsh: 100,
    perKmKsh: 35,
    perMinuteKsh: 4,
    minimumFareKsh: 150,
    surgeCap: 2.5,
  },
  mombasa: {
    baseFareKsh: 80,
    perKmKsh: 30,
    perMinuteKsh: 3,
    minimumFareKsh: 120,
    surgeCap: 2.0,
  },
  kisumu: {
    baseFareKsh: 70,
    perKmKsh: 28,
    perMinuteKsh: 3,
    minimumFareKsh: 100,
    surgeCap: 1.8,
  },
};