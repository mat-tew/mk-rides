import { prisma } from '../config/db.js';
import { mpesaClient } from '../services/mpesa.js';
import { logger } from '../utils/logger.js';

interface StkPushInput {
  rideId: string;
  phone: string;
  amountKsh: number;
}

interface B2cInput {
  driverId: string;
  amountKsh: number;
}

export const paymentController = {
  async stkPush(input: StkPushInput) {
    const result = await mpesaClient.stkPush({
      phone: input.phone,
      amount: input.amountKsh,
      accountReference: input.rideId,
      transactionDesc: `MK RIDES ride ${input.rideId}`,
    });

    await prisma.payment.create({
      data: {
        rideId: input.rideId,
        amountKsh: input.amountKsh,
        method: 'mpesa_stk',
        status: 'pending',
        merchantRequestId: result.MerchantRequestID,
        checkoutRequestId: result.CheckoutRequestID,
      },
    });

    return result;
  },

  async b2cPayout(input: B2cInput) {
    const driver = await prisma.driver.findUnique({ where: { id: input.driverId } });
    if (!driver) {
      throw Object.assign(new Error('Driver not found'), { statusCode: 404 });
    }
    const result = await mpesaClient.b2c({
      phone: driver.phone,
      amount: input.amountKsh,
      occasion: 'Driver payout',
    });
    const payout = await prisma.payout.create({
      data: {
        driverId: driver.id,
        driverName: driver.name ?? 'Driver',
        amountKsh: input.amountKsh,
        status: 'initiated',
        conversationId: result.ConversationID,
        originatorConversationId: result.OriginatorConversationID,
      },
    });
    return payout;
  },

  async handleCallback(payload: unknown) {
    // Persist Daraja callback for reconciliation. In production this
    // updates the matching Payment/Payout record and emits a Socket.IO
    // event to the passenger/driver client.
    logger.info({ payload }, 'Daraja callback received');
  },
};