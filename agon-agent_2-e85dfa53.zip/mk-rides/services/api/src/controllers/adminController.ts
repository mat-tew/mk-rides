import { prisma } from '../config/db.js';

export const adminController = {
  async dashboardStats() {
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const [activeRides, onlineDrivers, todayRides, pendingDrivers, revenueAgg] = await Promise.all([
      prisma.ride.count({ where: { status: { in: ['requested', 'matched', 'en_route', 'in_progress'] } } }),
      prisma.driver.count({ where: { online: true } }),
      prisma.ride.count({ where: { requestedAt: { gte: since } } }),
      prisma.driver.count({ where: { verificationStatus: 'pending' } }),
      prisma.ride.aggregate({ _sum: { fareKsh: true }, where: { requestedAt: { gte: since }, status: 'completed' } }),
    ]);
    return {
      activeRides,
      onlineDrivers,
      ridesToday: todayRides,
      revenueTodayKsh: revenueAgg._sum.fareKsh ?? 0,
      pendingVerifications: pendingDrivers,
    };
  },

  async listRides({ limit, cursor, status }: { limit: number; cursor?: string; status?: string }) {
    return prisma.ride.findMany({
      take: limit,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
      where: status ? { status } : undefined,
      orderBy: { requestedAt: 'desc' },
    });
  },

  async listDrivers({ status, limit }: { status?: string; limit: number }) {
    return prisma.driver.findMany({
      take: limit,
      where: status ? { verificationStatus: status } : undefined,
      orderBy: { createdAt: 'desc' },
    });
  },

  async listUsers({ limit }: { limit: number }) {
    return prisma.user.findMany({ take: limit, orderBy: { createdAt: 'desc' } });
  },

  async listPayouts({ limit }: { limit: number }) {
    return prisma.payout.findMany({ take: limit, orderBy: { initiatedAt: 'desc' } });
  },

  async approveDriver(id: string) {
    return prisma.driver.update({ where: { id }, data: { verificationStatus: 'approved' } });
  },
};