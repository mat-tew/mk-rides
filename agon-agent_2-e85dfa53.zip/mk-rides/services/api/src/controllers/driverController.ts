import { prisma } from '../config/db.js';
import { driverLocationStore } from '../sockets/index.js';

interface LocationInput {
  latitude: number;
  longitude: number;
  heading?: number;
  speed?: number;
}

interface ListInput {
  status?: string;
  limit: number;
}

export const driverController = {
  async apply(input: {
    name: string;
    phone: string;
    email?: string;
    licenseNumber: string;
    vehicle: { make: string; model: string; year: number; plate: string; color: string };
  }) {
    return prisma.driver.upsert({
      where: { phone: input.phone },
      create: {
        phone: input.phone,
        name: input.name,
        email: input.email,
        licenseNumber: input.licenseNumber,
        vehicle: input.vehicle,
        verificationStatus: 'pending',
      },
      update: { name: input.name, licenseNumber: input.licenseNumber, vehicle: input.vehicle },
    });
  },

  async setOnline(driverId: string, online: boolean) {
    return prisma.driver.update({
      where: { id: driverId },
      data: { online, lastSeenAt: new Date() },
    });
  },

  async updateLocation(driverId: string, fix: LocationInput) {
    driverLocationStore.set(driverId, fix);
    return prisma.driver.update({
      where: { id: driverId },
      data: {
        lastLat: fix.latitude,
        lastLng: fix.longitude,
        lastHeading: fix.heading,
        lastSeenAt: new Date(),
      },
    });
  },

  async list({ status, limit }: ListInput) {
    return prisma.driver.findMany({
      where: status ? { verificationStatus: status } : undefined,
      take: limit,
      orderBy: { createdAt: 'desc' },
    });
  },

  async earnings(driverId: string) {
    const rides = await prisma.ride.findMany({
      where: { driverId, status: 'completed' },
      orderBy: { completedAt: 'desc' },
      take: 30,
    });

    const todayKsh = rides
      .filter((r) => sameDay(r.completedAt, new Date()))
      .reduce((sum, r) => sum + r.fareKsh, 0);
    const weekKsh = rides
      .filter((r) => withinDays(r.completedAt, new Date(), 7))
      .reduce((sum, r) => sum + r.fareKsh, 0);
    const lifetimeKsh = rides.reduce((sum, r) => sum + r.fareKsh, 0);

    return {
      todayKsh,
      weekKsh,
      lifetimeKsh,
      recentTrips: rides.map((r) => ({
        rideId: r.id,
        pickup: r.pickupId,
        dropoff: r.dropoffId,
        completedAt: r.completedAt,
        fareKsh: r.fareKsh,
      })),
    };
  },
};

function sameDay(a: Date | null, b: Date): boolean {
  if (!a) return false;
  return a.toDateString() === b.toDateString();
}

function withinDays(a: Date | null, b: Date, days: number): boolean {
  if (!a) return false;
  return b.getTime() - a.getTime() <= days * 24 * 60 * 60 * 1000;
}