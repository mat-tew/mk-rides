import { prisma } from '../config/db.js';
import { fareCalculator } from '../services/fareCalculator.js';
import { rideMatching } from '../services/rideMatching.js';
import { logger } from '../utils/logger.js';
import type { Ride, LatLng } from '@mk-rides/shared-types';

interface QuoteInput {
  pickupId: string;
  dropoffId: string;
}

interface RequestInput {
  pickupId: string;
  dropoffId: string;
  productId: 'economy' | 'comfort' | 'xl';
  paymentMethodId?: string;
}

interface ListInput {
  status?: string;
  limit: number;
  cursor?: string;
}

export const rideController = {
  async quote({ pickupId, dropoffId }: QuoteInput) {
    const pickup = await prisma.place.findUnique({ where: { id: pickupId } });
    const dropoff = await prisma.place.findUnique({ where: { id: dropoffId } });
    if (!pickup || !dropoff) {
      throw Object.assign(new Error('Pickup or dropoff not found'), { statusCode: 404 });
    }
    return fareCalculator.quote(
      { latitude: pickup.lat, longitude: pickup.lng },
      { latitude: dropoff.lat, longitude: dropoff.lng },
      'nairobi',
    );
  },

  async request(passengerId: string, body: RequestInput): Promise<Ride> {
    const pickup = await prisma.place.findUnique({ where: { id: body.pickupId } });
    const dropoff = await prisma.place.findUnique({ where: { id: body.dropoffId } });
    if (!pickup || !dropoff) {
      throw Object.assign(new Error('Pickup or dropoff not found'), { statusCode: 404 });
    }

    const quote = fareCalculator.quote(
      { latitude: pickup.lat, longitude: pickup.lng },
      { latitude: dropoff.lat, longitude: dropoff.lng },
      'nairobi',
    );

    const ride = await prisma.ride.create({
      data: {
        passengerId,
        pickupId: pickup.id,
        dropoffId: dropoff.id,
        productId: body.productId,
        status: 'requested',
        fareKsh: quote.amountKsh,
        distanceKm: quote.distanceKm,
        etaMinutes: quote.etaMinutes,
        surgeMultiplier: quote.surgeMultiplier,
        requestedAt: new Date(),
      },
    });

    rideMatching.dispatch(ride.id).catch((err) => logger.error({ err, rideId: ride.id }, 'Dispatch failed'));
    return ride;
  },

  async cancel(rideId: string) {
    const ride = await prisma.ride.update({
      where: { id: rideId },
      data: { status: 'cancelled', cancelledAt: new Date() },
    });
    rideMatching.cancelDispatch(ride.id).catch(() => undefined);
    return ride;
  },

  async accept(rideId: string) {
    return prisma.ride.update({
      where: { id: rideId },
      data: { status: 'matched', matchedAt: new Date() },
    });
  },

  async complete(rideId: string) {
    return prisma.ride.update({
      where: { id: rideId },
      data: { status: 'completed', completedAt: new Date() },
    });
  },

  async list({ status, limit, cursor }: ListInput) {
    return prisma.ride.findMany({
      where: status ? { status } : undefined,
      take: limit,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
      orderBy: { requestedAt: 'desc' },
    });
  },

  async history(userId: string) {
    return prisma.ride.findMany({
      where: { passengerId: userId },
      orderBy: { requestedAt: 'desc' },
      take: 30,
    });
  },
};

export type { LatLng };