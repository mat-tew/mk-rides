import { z } from 'zod';
import bcrypt from 'bcrypt';

import { prisma } from '../config/db.js';
import { env } from '../config/env.js';
import { smsService } from '../services/sms.js';
import { logger } from '../utils/logger.js';
import type { Role, Session } from '@mk-rides/shared-types';

// In-memory OTP store for the initial commit. Production deployments
// swap this for Redis with a short TTL. The shape is `{ phone -> { code, expiresAt } }`.
const otpStore = new Map<string, { code: string; expiresAt: number }>();
const OTP_TTL_MS = 5 * 60 * 1000; // 5 minutes

function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export const authController = {
  async requestOtp(phone: string, role: Role): Promise<{ sent: true }> {
    const code = generateOtp();
    otpStore.set(phone, { code, expiresAt: Date.now() + OTP_TTL_MS });

    try {
      await smsService.send(phone, `Your MK RIDES code is ${code}. It expires in 5 minutes.`);
    } catch (err) {
      logger.warn({ err, phone }, 'SMS delivery failed; OTP stored but not sent');
    }

    // Ensure the user record exists (passenger or driver) so the verify step is a single round trip.
    if (role === 'driver') {
      await prisma.driver.upsert({
        where: { phone },
        create: { phone, verificationStatus: 'pending' },
        update: {},
      });
    } else {
      await prisma.user.upsert({
        where: { phone },
        create: { phone, role: 'passenger' },
        update: {},
      });
    }

    return { sent: true };
  },

  async verifyOtp(phone: string, code: string, role: Role): Promise<Session> {
    const record = otpStore.get(phone);
    if (!record || record.expiresAt < Date.now() || record.code !== code) {
      throw Object.assign(new Error('Invalid or expired code'), { statusCode: 401 });
    }
    otpStore.delete(phone);

    const user =
      role === 'driver'
        ? await prisma.driver.findUnique({ where: { phone } })
        : await prisma.user.findUnique({ where: { phone } });

    if (!user) {
      throw Object.assign(new Error('Account not found'), { statusCode: 404 });
    }

    const token = await issueJwt({ sub: user.id, role });
    return {
      accessToken: token,
      refreshToken: token, // initial commit: same JWT, refresh logic in a follow-up
      user: { id: user.id, name: user.name, phone: user.phone, role },
    };
  },

  async adminLogin(email: string, password: string): Promise<Session> {
    const admin = await prisma.adminUser.findUnique({ where: { email } });
    if (!admin) {
      throw Object.assign(new Error('Invalid credentials'), { statusCode: 401 });
    }
    const ok = await bcrypt.compare(password, admin.passwordHash);
    if (!ok) {
      throw Object.assign(new Error('Invalid credentials'), { statusCode: 401 });
    }
    const token = await issueJwt({ sub: admin.id, role: 'admin' });
    return {
      accessToken: token,
      refreshToken: token,
      user: { id: admin.id, name: admin.name, email, role: 'admin' },
    };
  },

  async refresh(refreshToken: string): Promise<Session> {
    const payload = z
      .object({ sub: z.string(), role: z.enum(['passenger', 'driver', 'admin', 'operator', 'finance']) })
      .parse(JSON.parse(Buffer.from(refreshToken.split('.')[1], 'base64').toString()));
    const token = await issueJwt(payload);
    return { accessToken: token, refreshToken: token, user: { id: payload.sub, role: payload.role } };
  },
};

async function issueJwt(payload: { sub: string; role: Role }): Promise<string> {
  // Using the @fastify/jwt instance attached to the app. In controllers we
  // can't access it directly, so this helper accepts the signing key.
  const { default: jwt } = await import('jsonwebtoken');
  return jwt.sign(payload, env.JWT_SECRET, { expiresIn: env.JWT_EXPIRES_IN });
}