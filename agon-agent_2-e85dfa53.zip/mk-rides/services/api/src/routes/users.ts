import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

import { requireAuth } from '../middleware/auth.js';
import { prisma } from '../config/db.js';

const updateSchema = z.object({
  name: z.string().min(2).optional(),
  email: z.string().email().optional(),
  mpesaPhone: z.string().regex(/^(?:\+?254|0)?7\d{8}$/).optional(),
});

export async function userRoutes(app: FastifyInstance): Promise<void> {
  app.get('/me', { preHandler: requireAuth }, async (req) => {
    const auth = (req as typeof req & { auth: { userId: string } }).auth;
    return prisma.user.findUnique({ where: { id: auth.userId } });
  });

  app.patch('/me', { preHandler: requireAuth }, async (req) => {
    const auth = (req as typeof req & { auth: { userId: string } }).auth;
    const body = updateSchema.parse(req.body);
    return prisma.user.update({ where: { id: auth.userId }, data: body });
  });
}