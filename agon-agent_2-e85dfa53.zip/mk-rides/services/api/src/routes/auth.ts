import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

import { authController } from '../controllers/authController.js';

const requestOtpSchema = z.object({
  phone: z.string().regex(/^(?:\+?254|0)?7\d{8}$/, 'Invalid Kenyan phone number'),
  role: z.enum(['passenger', 'driver']).default('passenger'),
});

const verifyOtpSchema = z.object({
  phone: z.string().regex(/^(?:\+?254|0)?7\d{8}$/),
  code: z.string().length(6),
  role: z.enum(['passenger', 'driver']).default('passenger'),
});

const adminLoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

export async function authRoutes(app: FastifyInstance): Promise<void> {
  app.post('/request-otp', async (req, reply) => {
    const body = requestOtpSchema.parse(req.body);
    const result = await authController.requestOtp(body.phone, body.role);
    return reply.code(202).send(result);
  });

  app.post('/verify-otp', async (req, reply) => {
    const body = verifyOtpSchema.parse(req.body);
    const session = await authController.verifyOtp(body.phone, body.code, body.role);
    return reply.send(session);
  });

  app.post('/admin/login', async (req, reply) => {
    const body = adminLoginSchema.parse(req.body);
    const session = await authController.adminLogin(body.email, body.password);
    return reply.send(session);
  });

  app.post('/refresh', async (req, reply) => {
    const { refreshToken } = z.object({ refreshToken: z.string() }).parse(req.body);
    const session = await authController.refresh(refreshToken);
    return reply.send(session);
  });
}