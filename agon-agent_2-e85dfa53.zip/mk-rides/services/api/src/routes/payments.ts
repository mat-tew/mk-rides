import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

import { paymentController } from '../controllers/paymentController.js';

const stkPushSchema = z.object({
  rideId: z.string(),
  phone: z.string().regex(/^(?:\+?254|0)?7\d{8}$/),
  amountKsh: z.number().int().positive(),
});

const b2cSchema = z.object({
  driverId: z.string(),
  amountKsh: z.number().int().positive(),
});

export async function paymentRoutes(app: FastifyInstance): Promise<void> {
  app.post('/mpesa/stk-push', async (req) => {
    const body = stkPushSchema.parse(req.body);
    return paymentController.stkPush(body);
  });

  app.post('/mpesa/b2c', async (req) => {
    const body = b2cSchema.parse(req.body);
    return paymentController.b2cPayout(body);
  });

  app.post('/mpesa/callback', async (req, reply) => {
    await paymentController.handleCallback(req.body);
    return reply.code(200).send({ received: true });
  });
}