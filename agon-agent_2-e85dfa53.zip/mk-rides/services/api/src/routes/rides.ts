import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

import { rideController } from '../controllers/rideController.js';
import { requireAuth } from '../middleware/auth.js';

const quoteSchema = z.object({
  pickupId: z.string(),
  dropoffId: z.string(),
});

const requestSchema = z.object({
  pickupId: z.string(),
  dropoffId: z.string(),
  productId: z.enum(['economy', 'comfort', 'xl']).default('economy'),
  paymentMethodId: z.string().optional(),
});

const listSchema = z.object({
  status: z.enum(['requested', 'matched', 'en_route', 'in_progress', 'completed', 'cancelled']).optional(),
  limit: z.coerce.number().int().positive().max(200).default(50),
  cursor: z.string().optional(),
});

export async function rideRoutes(app: FastifyInstance): Promise<void> {
  app.get('/quote', async (req) => {
    const body = quoteSchema.parse(req.query);
    return rideController.quote(body);
  });

  app.post('/request', { preHandler: requireAuth }, async (req, reply) => {
    const body = requestSchema.parse(req.body);
    const auth = (req as typeof req & { auth: { userId: string } }).auth;
    const ride = await rideController.request(auth.userId, body);
    return reply.code(201).send(ride);
  });

  app.post('/:id/cancel', { preHandler: requireAuth }, async (req) => {
    const { id } = z.object({ id: z.string() }).parse(req.params);
    return rideController.cancel(id);
  });

  app.post('/:id/accept', { preHandler: requireAuth }, async (req) => {
    const { id } = z.object({ id: z.string() }).parse(req.params);
    return rideController.accept(id);
  });

  app.post('/:id/complete', { preHandler: requireAuth }, async (req) => {
    const { id } = z.object({ id: z.string() }).parse(req.params);
    return rideController.complete(id);
  });

  app.get('/', { preHandler: requireAuth }, async (req) => {
    const query = listSchema.parse(req.query);
    return rideController.list(query);
  });

  app.get('/history', { preHandler: requireAuth }, async (req) => {
    const auth = (req as typeof req & { auth: { userId: string } }).auth;
    return rideController.history(auth.userId);
  });
}