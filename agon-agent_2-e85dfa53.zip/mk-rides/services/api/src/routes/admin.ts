import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

import { adminController } from '../controllers/adminController.js';
import { requireRole } from '../middleware/auth.js';

export async function adminRoutes(app: FastifyInstance): Promise<void> {
  app.get('/stats', { preHandler: requireRole('admin', 'operator') }, async () => {
    return adminController.dashboardStats();
  });

  app.get('/rides', { preHandler: requireRole('admin', 'operator') }, async (req) => {
    const query = z
      .object({
        limit: z.coerce.number().int().positive().max(500).default(100),
        cursor: z.string().optional(),
        status: z.enum(['requested', 'matched', 'en_route', 'in_progress', 'completed', 'cancelled']).optional(),
      })
      .parse(req.query);
    return adminController.listRides(query);
  });

  app.get('/drivers', { preHandler: requireRole('admin', 'operator') }, async (req) => {
    const query = z
      .object({
        status: z.enum(['pending', 'approved', 'suspended', 'rejected']).optional(),
        limit: z.coerce.number().int().positive().max(500).default(100),
      })
      .parse(req.query);
    return adminController.listDrivers(query);
  });

  app.get('/users', { preHandler: requireRole('admin') }, async (req) => {
    const query = z
      .object({ limit: z.coerce.number().int().positive().max(500).default(100) })
      .parse(req.query);
    return adminController.listUsers(query);
  });

  app.get('/payouts', { preHandler: requireRole('admin', 'finance') }, async (req) => {
    const query = z
      .object({ limit: z.coerce.number().int().positive().max(500).default(100) })
      .parse(req.query);
    return adminController.listPayouts(query);
  });

  app.post('/drivers/:id/approve', { preHandler: requireRole('admin') }, async (req) => {
    const { id } = z.object({ id: z.string() }).parse(req.params);
    return adminController.approveDriver(id);
  });
}