import type { FastifyInstance } from 'fastify';
import { z } from 'zod';

import { driverController } from '../controllers/driverController.js';
import { requireAuth } from '../middleware/auth.js';

const locationSchema = z.object({
  latitude: z.number().gte(-90).lte(90),
  longitude: z.number().gte(-180).lte(180),
  heading: z.number().optional(),
  speed: z.number().optional(),
});

const onlineSchema = z.object({
  online: z.boolean(),
});

const listSchema = z.object({
  status: z.enum(['pending', 'approved', 'suspended', 'rejected']).optional(),
  limit: z.coerce.number().int().positive().max(200).default(100),
});

export async function driverRoutes(app: FastifyInstance): Promise<void> {
  app.post('/location', { preHandler: requireAuth }, async (req) => {
    const auth = (req as typeof req & { auth: { userId: string } }).auth;
    const body = locationSchema.parse(req.body);
    return driverController.updateLocation(auth.userId, body);
  });

  app.post('/online', { preHandler: requireAuth }, async (req) => {
    const auth = (req as typeof req & { auth: { userId: string } }).auth;
    const body = onlineSchema.parse(req.body);
    return driverController.setOnline(auth.userId, body.online);
  });

  app.post('/apply', async (req) => {
    const body = z
      .object({
        name: z.string().min(2),
        phone: z.string().regex(/^(?:\+?254|0)?7\d{8}$/),
        email: z.string().email().optional(),
        licenseNumber: z.string().min(4),
        vehicle: z.object({
          make: z.string(),
          model: z.string(),
          year: z.number().int().min(2000).max(new Date().getFullYear() + 1),
          plate: z.string().min(3),
          color: z.string(),
        }),
      })
      .parse(req.body);
    return driverController.apply(body);
  });

  app.get('/', { preHandler: requireAuth }, async (req) => {
    const query = listSchema.parse(req.query);
    return driverController.list(query);
  });

  app.get('/earnings', { preHandler: requireAuth }, async (req) => {
    const auth = (req as typeof req & { auth: { userId: string } }).auth;
    return driverController.earnings(auth.userId);
  });
}