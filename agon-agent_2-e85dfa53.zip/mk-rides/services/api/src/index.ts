import { buildServer } from './server.js';
import { env } from './config/env.js';
import { logger } from './utils/logger.js';

/**
 * Entry point. Boots the Fastify server, prints the URL, and exits
 * non-zero if startup fails so the process supervisor (pm2/systemd)
 * can restart it.
 */
async function main() {
  const server = await buildServer();

  try {
    await server.listen({ port: env.PORT, host: env.HOST });
    logger.info({ url: server.printRoutes() }, 'API listening');
  } catch (err) {
    logger.error({ err }, 'Failed to start API');
    process.exit(1);
  }

  const shutdown = async (signal: string) => {
    logger.info({ signal }, 'Shutting down');
    await server.close();
    process.exit(0);
  };
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));
}

main();