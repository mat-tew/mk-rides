import type { LatLng, Quote } from '@mk-rides/shared-types';

import { CITY_PRICING } from '../config/pricing.js';
import { haversineKm } from '../utils/geo.js';

/**
 * Pure fare calculator. Quotes are deterministic given distance, duration
 * and city; surge multiplier is computed from current demand and is
 * supplied by the dispatch service.
 */
export const fareCalculator = {
  quote(pickup: LatLng, dropoff: LatLng, city: keyof typeof CITY_PRICING, surgeMultiplier = 1): Quote {
    const distanceKm = haversineKm(pickup, dropoff);
    const etaMinutes = estimateEtaMinutes(distanceKm);
    const pricing = CITY_PRICING[city];

    const raw =
      pricing.baseFareKsh +
      pricing.perKmKsh * distanceKm +
      pricing.perMinuteKsh * etaMinutes;
    const surgeAdjusted = raw * Math.min(surgeMultiplier, pricing.surgeCap);
    const amountKsh = Math.max(Math.round(surgeAdjusted), pricing.minimumFareKsh);

    return {
      amountKsh,
      currency: 'KES',
      etaMinutes,
      distanceKm,
      surgeMultiplier,
    };
  },
};

function estimateEtaMinutes(distanceKm: number): number {
  // Assume 25 km/h average urban speed in Nairobi traffic.
  return Math.max(2, Math.round((distanceKm / 25) * 60));
}