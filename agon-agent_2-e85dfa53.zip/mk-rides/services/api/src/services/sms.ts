import { env } from '../config/env.js';
import { logger } from '../utils/logger.js';

/**
 * SMS delivery for OTP and notifications. Uses Africa's Talking in
 * production; the sandbox endpoint is reachable without real
 * credentials when `AT_USERNAME=sandbox` is set.
 */
export const smsService = {
  async send(phone: string, message: string): Promise<void> {
    if (!env.AT.API_KEY) {
      // Dev mode — log to the console instead of calling the gateway.
      logger.info({ phone, message }, 'SMS (dev mode, not sent)');
      return;
    }
    const res = await fetch('https://api.africastalking.com/version1/messaging', {
      method: 'POST',
      headers: {
        apiKey: env.AT.API_KEY,
        Accept: 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        username: env.AT.USERNAME,
        to: phone,
        message,
      }).toString(),
    });
    if (!res.ok) {
      throw new Error(`SMS send failed: ${res.status}`);
    }
  },
};