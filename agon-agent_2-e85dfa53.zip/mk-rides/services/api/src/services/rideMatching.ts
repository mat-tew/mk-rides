import { prisma } from '../config/db.js';
import { driverLocationStore } from '../sockets/index.js';
import { logger } from '../utils/logger.js';
import type { LatLng } from '@mk-rides/shared-types';

/**
 * Ride matching service. The first commit uses a simple "nearest online
 * driver" heuristic. Production deploys swap this for an OR-tools
 * solver (or a hosted dispatch service) and a queue per city.
 */
export const rideMatching = {
  async dispatch(rideId: string): Promise<void> {
    const ride = await prisma.ride.findUnique({
      where: { id: rideId },
      include: { pickup: true },
    });
    if (!ride) return;

    const candidates = await prisma.driver.findMany({
      where: { online: true, verificationStatus: 'approved' },
    });

    const nearby = candidates
      .map((d) => ({
        driver: d,
        distanceKm: distanceKmFrom(d, ride.pickup),
      }))
      .filter((c) => c.distanceKm <= 5)
      .sort((a, b) => a.distanceKm - b.distanceKm);

    if (nearby.length === 0) {
      logger.warn({ rideId }, 'No eligible drivers nearby');
      return;
    }

    const chosen = nearby[0];
    await prisma.ride.update({
      where: { id: rideId },
      data: { driverId: chosen.driver.id, status: 'matched', matchedAt: new Date() },
    });
    // Push the offer over Socket.IO. Real implementations time-box
    // acceptance and roll to the next driver on decline.
    const io = (globalThis as { __io?: import('socket.io').Server }).__io;
    io?.to(`driver:${chosen.driver.id}`).emit('ride:offer', { rideId });
  },

  async cancelDispatch(rideId: string): Promise<void> {
    const io = (globalThis as { __io?: import('socket.io').Server }).__io;
    io?.to(`ride:${rideId}`).emit('ride:cancelled', { rideId });
  },
};

function distanceKmFrom(d: { lastLat: number | null; lastLng: number | null }, pickup: { lat: number; lng: number }): number {
  if (d.lastLat == null || d.lastLng == null) return Infinity;
  return haversineKm({ latitude: d.lastLat, longitude: d.lastLng }, { latitude: pickup.lat, longitude: pickup.lng });
}

function haversineKm(a: LatLng, b: LatLng): number {
  const R = 6371;
  const dLat = ((b.latitude - a.latitude) * Math.PI) / 180;
  const dLon = ((b.longitude - a.longitude) * Math.PI) / 180;
  const lat1 = (a.latitude * Math.PI) / 180;
  const lat2 = (b.latitude * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 + Math.sin(dLon / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * R * Math.asin(Math.sqrt(h));
}