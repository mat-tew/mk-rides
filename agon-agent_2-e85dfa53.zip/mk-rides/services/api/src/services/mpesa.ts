import { env } from '../config/env.js';
import { logger } from '../utils/logger.js';

/**
 * Thin wrapper around the Safaricom Daraja API. The initial commit
 * targets the sandbox endpoints. Real deployments load credentials
 * from a secret manager; the `.env.example` ships `replace-me`
 * placeholders so the file is safe to commit.
 */
const BASE = env.MPESA.ENVIRONMENT === 'production'
  ? 'https://api.safaricom.co.ke'
  : 'https://sandbox.safaricom.co.ke';

let cachedToken: { token: string; expiresAt: number } | null = null;

async function getAccessToken(): Promise<string> {
  if (cachedToken && cachedToken.expiresAt > Date.now() + 60_000) {
    return cachedToken.token;
  }
  const auth = Buffer.from(`${env.MPESA.CONSUMER_KEY}:${env.MPESA.CONSUMER_SECRET}`).toString('base64');
  const res = await fetch(`${BASE}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` },
  });
  if (!res.ok) {
    throw new Error(`M-Pesa token request failed: ${res.status}`);
  }
  const data = (await res.json()) as { access_token: string; expires_in: string };
  cachedToken = {
    token: data.access_token,
    expiresAt: Date.now() + Number(data.expires_in) * 1000,
  };
  return data.access_token;
}

export const mpesaClient = {
  async stkPush(input: { phone: string; amount: number; accountReference: string; transactionDesc: string }) {
    const token = await getAccessToken();
    const timestamp = new Date()
      .toISOString()
      .replace(/[-:T.Z]/g, '')
      .slice(0, 14);
    const password = Buffer.from(`${env.MPESA.SHORTCODE}${env.MPESA.PASSKEY}${timestamp}`).toString('base64');

    const res = await fetch(`${BASE}/mpesa/stkpush/v1/processrequest`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        BusinessShortCode: env.MPESA.SHORTCODE,
        Password: password,
        Timestamp: timestamp,
        TransactionType: 'CustomerPayBillOnline',
        Amount: input.amount,
        PartyA: input.phone,
        PartyB: env.MPESA.SHORTCODE,
        PhoneNumber: input.phone,
        CallBackURL: env.MPESA.CALLBACK_URL,
        AccountReference: input.accountReference,
        TransactionDesc: input.transactionDesc,
      }),
    });
    if (!res.ok) {
      logger.error({ status: res.status, body: await res.text() }, 'STK push failed');
      throw new Error('STK push failed');
    }
    return (await res.json()) as { MerchantRequestID: string; CheckoutRequestID: string; ResponseCode: string };
  },

  async b2c(input: { phone: string; amount: number; occasion: string }) {
    const token = await getAccessToken();
    const res = await fetch(`${BASE}/mpesa/b2c/v3/paymentrequest`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        InitiatorName: env.MPESA.B2C_INITIATOR_NAME,
        SecurityCredential: env.MPESA.B2C_SECURITY_CREDENTIAL,
        CommandID: 'BusinessPayment',
        Amount: input.amount,
        PartyA: env.MPESA.SHORTCODE,
        PartyB: input.phone,
        Remarks: input.occasion,
        QueueTimeOutURL: `${env.MPESA.CALLBACK_URL}/b2c/timeout`,
        ResultURL: `${env.MPESA.CALLBACK_URL}/b2c/result`,
        Occasion: input.occasion,
      }),
    });
    if (!res.ok) {
      logger.error({ status: res.status, body: await res.text() }, 'B2C failed');
      throw new Error('B2C failed');
    }
    return (await res.json()) as { ConversationID: string; OriginatorConversationID: string; ResponseCode: string };
  },
};