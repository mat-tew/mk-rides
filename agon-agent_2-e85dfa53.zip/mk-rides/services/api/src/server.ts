import Fastify, { type FastifyInstance } from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import jwt from '@fastify/jwt';
import rateLimit from '@fastify/rate-limit';
import socketIO from '@fastify/socket.io';

import { env } from './config/env.js';
import { logger } from './utils/logger.js';
import { errorHandler } from './middleware/errorHandler.js';
import { authRoutes } from './routes/auth.js';
import { rideRoutes } from './routes/rides.js';
import { driverRoutes } from './routes/drivers.js';
import { userRoutes } from './routes/users.js';
import { paymentRoutes } from './routes/payments.js';
import { adminRoutes } from './routes/admin.js';
import { registerSocketHandlers } from './sockets/index.js';

/**
 * Builds (but does not start) the Fastify server. Exported separately so
 * tests can spin up an instance against an in-memory database.
 */
export async function buildServer(): Promise<FastifyInstance> {
  const app = Fastify({
    logger: logger as unknown as FastifyInstance['log'],
    trustProxy: true,
  });

  await app.register(helmet);
  await app.register(cors, {
    origin: env.CORS_ORIGINS.split(',').map((s) => s.trim()),
    credentials: true,
  });
  await app.register(rateLimit, { max: 200, timeWindow: '1 minute' });
  await app.register(jwt, { secret: env.JWT_SECRET });
  await app.register(socketIO, { cors: { origin: env.CORS_ORIGINS.split(',') } });

  app.setErrorHandler(errorHandler);

  // Health
  app.get('/health', async () => ({ status: 'ok', service: 'mk-rides-api', time: new Date().toISOString() }));

  // REST routes
  await app.register(authRoutes, { prefix: '/api/auth' });
  await app.register(rideRoutes, { prefix: '/api/rides' });
  await app.register(driverRoutes, { prefix: '/api/drivers' });
  await app.register(userRoutes, { prefix: '/api/users' });
  await app.register(paymentRoutes, { prefix: '/api/payments' });
  await app.register(adminRoutes, { prefix: '/api/admin' });

  // Socket.IO
  registerSocketHandlers(app);

  return app;
}