import type { FastifyInstance } from 'fastify';

import { logger } from '../utils/logger.js';

/**
 * In-memory cache of the most recent driver location, keyed by driver id.
 * Production deployments swap this for Redis with a short TTL so multiple
 * API instances share the same picture.
 */
export const driverLocationStore = new Map<
  string,
  { latitude: number; longitude: number; heading?: number; speed?: number; ts: number }
>();

/**
 * Wires up Socket.IO channels for ride dispatch and live tracking.
 *
 * Channels:
 * - `driver:<driverId>`  — ride offers pushed to a specific driver
 * - `ride:<rideId>`      — passenger/driver share driver location + status
 */
export function registerSocketHandlers(app: FastifyInstance): void {
  app.ready((err) => {
    if (err) {
      logger.error({ err }, 'Socket.IO ready failed');
      return;
    }
    const io = app.io;
    (globalThis as { __io?: typeof io }).__io = io;

    io.on('connection', (socket) => {
      socket.on('driver:online', ({ driverId }: { driverId: string }) => {
        socket.join(`driver:${driverId}`);
      });
      socket.on(
        'driver:location',
        (payload: { driverId: string; latitude: number; longitude: number; heading?: number; speed?: number }) => {
          driverLocationStore.set(payload.driverId, { ...payload, ts: Date.now() });
          socket.to(`ride:${(socket.data as { rideId?: string }).rideId ?? ''}`).emit('driver:location', payload);
        },
      );
      socket.on('ride:subscribe', ({ rideId }: { rideId: string }) => {
        socket.join(`ride:${rideId}`);
        (socket.data as { rideId?: string }).rideId = rideId;
      });
    });
  });
}