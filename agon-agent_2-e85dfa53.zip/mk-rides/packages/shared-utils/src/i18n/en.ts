/**
 * English copy used across the passenger and driver apps. Strings live
 * here so they can be reviewed in PRs without touching component code.
 */
export const en = {
  common: {
    loading: 'Loading…',
    error: 'Something went wrong',
    retry: 'Retry',
    cancel: 'Cancel',
    confirm: 'Confirm',
  },
  ride: {
    request: 'Request ride',
    cancel: 'Cancel ride',
    onTheWay: 'Your driver is on the way',
    arrived: 'Your driver has arrived',
    complete: 'Ride complete',
  },
  driver: {
    online: 'You are online',
    offline: 'You are offline',
    accept: 'Accept',
    decline: 'Decline',
  },
};