/**
 * Swahili copy used across the passenger and driver apps.
 */
export const sw = {
  common: {
    loading: 'Inapakia…',
    error: 'Hitilafu imetokea',
    retry: 'Jaribu tena',
    cancel: 'Ghairi',
    confirm: 'Thibitisha',
  },
  ride: {
    request: 'Omba teksi',
    cancel: 'Ghairi teksi',
    onTheWay: 'Dereva wako njiani',
    arrived: 'Dereva wako amefika',
    complete: 'Safari imekamilika',
  },
  driver: {
    online: 'Uko mtandaoni',
    offline: 'Uko nje ya mtandao',
    accept: 'Kubali',
    decline: 'Kataa',
  },
};