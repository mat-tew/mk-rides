import type {
  DashboardStats,
  EarningsSummary,
  FareQuoteRequest,
  Payout,
  Quote,
  RequestRideRequest,
  Ride,
  Session,
} from '@mk-rides/shared-types';

export interface ApiClientOptions {
  baseUrl: string;
  /** Optional function that returns the current access token. */
  getAccessToken?: () => string | null;
  /** Optional fetch implementation (useful in tests). */
  fetchImpl?: typeof fetch;
}

export interface ApiClient {
  requestOtp(body: { phone: string; role?: 'passenger' | 'driver' }): Promise<{ sent: true }>;
  verifyOtp(body: { phone: string; code: string; role?: 'passenger' | 'driver' }): Promise<Session>;
  adminLogin(body: { email: string; password: string }): Promise<Session>;

  fareQuote(body: FareQuoteRequest): Promise<Quote>;
  requestRide(body: RequestRideRequest): Promise<Ride>;
  cancelRide(rideId: string): Promise<Ride>;
  acceptRide(rideId: string): Promise<Ride>;
  rideHistory(): Promise<Ride[]>;

  setDriverOnline(online: boolean): Promise<{ online: boolean }>;
  driverEarnings(): Promise<EarningsSummary>;

  dashboardStats(): Promise<DashboardStats>;
  listRides(params: { limit?: number; cursor?: string; status?: string }): Promise<{ rides: Ride[] }>;
  listDrivers(params: { limit?: number; status?: string }): Promise<{ drivers: any[] }>;
  listUsers(params: { limit?: number }): Promise<{ users: any[] }>;
  listPayouts(params: { limit?: number }): Promise<{ payouts: Payout[] }>;
}

/**
 * Builds a typed MK RIDES API client. The implementation is fetch-based
 * so it works in the browser, in React Native, and in Node tests.
 */
export function createApiClient(options: ApiClientOptions): ApiClient {
  const f = options.fetchImpl ?? fetch;

  async function call<T>(method: string, path: string, body?: unknown): Promise<T> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    const token = options.getAccessToken?.();
    if (token) headers.Authorization = `Bearer ${token}`;

    const res = await f(`${options.baseUrl}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`${method} ${path} → ${res.status} ${text}`);
    }
    return (await res.json()) as T;
  }

  return {
    requestOtp: (body) => call('POST', '/api/auth/request-otp', body),
    verifyOtp: (body) => call('POST', '/api/auth/verify-otp', body),
    adminLogin: (body) => call('POST', '/api/auth/admin/login', body),

    fareQuote: (body) => call('GET', `/api/rides/quote?pickupId=${body.pickupId}&dropoffId=${body.dropoffId}`),
    requestRide: (body) => call('POST', '/api/rides/request', body),
    cancelRide: (id) => call('POST', `/api/rides/${id}/cancel`),
    acceptRide: (id) => call('POST', `/api/rides/${id}/accept`),
    rideHistory: () => call('GET', '/api/rides/history'),

    setDriverOnline: (online) => call('POST', '/api/drivers/online', { online }),
    driverEarnings: () => call('GET', '/api/drivers/earnings'),

    dashboardStats: () => call('GET', '/api/admin/stats'),
    listRides: (params) => {
      const qs = new URLSearchParams();
      if (params.limit) qs.set('limit', String(params.limit));
      if (params.cursor) qs.set('cursor', params.cursor);
      if (params.status) qs.set('status', params.status);
      return call('GET', `/api/admin/rides?${qs.toString()}`);
    },
    listDrivers: (params) => {
      const qs = new URLSearchParams();
      if (params.limit) qs.set('limit', String(params.limit));
      if (params.status) qs.set('status', params.status);
      return call('GET', `/api/admin/drivers?${qs.toString()}`);
    },
    listUsers: (params) => {
      const qs = new URLSearchParams();
      if (params.limit) qs.set('limit', String(params.limit));
      return call('GET', `/api/admin/users?${qs.toString()}`);
    },
    listPayouts: (params) => {
      const qs = new URLSearchParams();
      if (params.limit) qs.set('limit', String(params.limit));
      return call('GET', `/api/admin/payouts?${qs.toString()}`);
    },
  };
}