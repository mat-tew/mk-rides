/**
 * Domain types shared by every MK RIDES workspace. Keeping a single
 * source of truth here prevents drift between the mobile apps, the
 * admin dashboard, and the backend.
 */

export type Role = 'passenger' | 'driver' | 'admin' | 'operator' | 'finance';

export type VerificationStatus = 'pending' | 'approved' | 'suspended' | 'rejected';

export type RideStatus =
  | 'requested'
  | 'matched'
  | 'en_route'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export type PaymentStatus = 'pending' | 'succeeded' | 'failed' | 'reversed';

export type PayoutStatus = 'initiated' | 'completed' | 'failed';

export interface LatLng {
  latitude: number;
  longitude: number;
}

export interface Place extends LatLng {
  id: string;
  name: string;
  address: string;
  city?: string;
}

export interface User {
  id: string;
  name?: string;
  phone: string;
  email?: string;
  role: Role;
  createdAt: string;
  mpesaSuffix?: string;
}

export interface Vehicle {
  make: string;
  model: string;
  year: number;
  plate: string;
  color: string;
}

export interface DriverProfile {
  id: string;
  name?: string;
  phone: string;
  rating: number;
  verificationStatus: VerificationStatus;
  vehicle?: Vehicle;
}

export interface Ride {
  id: string;
  pickup: Place;
  dropoff: Place;
  productId: 'economy' | 'comfort' | 'xl';
  status: RideStatus;
  fareKsh: number;
  distanceKm: number;
  etaMinutes: number;
  surgeMultiplier: number;
  requestedAt: string;
  matchedAt?: string;
  completedAt?: string;
  cancelledAt?: string;
  driverId?: string;
  passengerId: string;
}

export interface Session {
  accessToken: string;
  refreshToken: string;
  user: { id: string; name?: string; phone?: string; email?: string; role: Role };
}

export interface Quote {
  amountKsh: number;
  currency: 'KES';
  etaMinutes: number;
  distanceKm: number;
  surgeMultiplier: number;
}

export interface CityPricing {
  baseFareKsh: number;
  perKmKsh: number;
  perMinuteKsh: number;
  minimumFareKsh: number;
  surgeCap: number;
}

export interface DashboardStats {
  activeRides: number;
  onlineDrivers: number;
  ridesToday: number;
  revenueTodayKsh: number;
  pendingVerifications: number;
}

export interface Payout {
  id: string;
  driverId: string;
  driverName: string;
  amountKsh: number;
  status: PayoutStatus;
  initiatedAt: string;
  completedAt?: string;
}

export interface EarningsSummary {
  todayKsh: number;
  weekKsh: number;
  lifetimeKsh: number;
  recentTrips: Array<{
    rideId: string;
    pickup: string;
    dropoff: string;
    completedAt: string;
    fareKsh: number;
  }>;
}

export interface FareQuoteRequest {
  pickupId: string;
  dropoffId: string;
}

export interface RequestRideRequest {
  pickupId: string;
  dropoffId: string;
  productId?: 'economy' | 'comfort' | 'xl';
  paymentMethodId?: string;
}