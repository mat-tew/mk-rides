# MK RIDES — Initial Commit Manifest

A one-line purpose for every file in this commit. Pair with `repo-file-map.txt`
for the visual tree.

## Root (14)

| File | Purpose |
|------|---------|
| `README.md` | Project overview, setup, architecture, Kenya-specific notes |
| `LICENSE` | MIT license |
| `CONTRIBUTING.md` | Workflow, commit conventions, code style |
| `SECURITY.md` | Vulnerability reporting policy and secret-rotation schedule |
| `CODEOWNERS` | Default code owners per workspace |
| `package.json` | Root npm workspaces config (`apps/*`, `services/*`, `packages/*`) |
| `tsconfig.base.json` | Shared TypeScript compiler options |
| `.gitignore` | Excludes `node_modules`, build output, native, env files |
| `.gitattributes` | Line-ending and text/binary rules |
| `.editorconfig` | Indent, charset, final-newline rules |
| `.prettierrc.json` | Prettier formatting config |
| `.eslintrc.cjs` | Shared ESLint config |
| `.nvmrc` | Node.js 20 |
| `.env.example` | Workspace-level env template with `replace-me` placeholders |

## `apps/passenger/` — Expo passenger app (24)

| File | Purpose |
|------|---------|
| `package.json` | Expo, RN, React Navigation, Zustand, socket.io-client |
| `app.json` | Expo config (iOS/Android bundle IDs, permissions) |
| `babel.config.js` | Babel preset + reanimated plugin |
| `metro.config.js` | Metro config that resolves monorepo packages |
| `tsconfig.json` | Extends base, adds React Native + path aliases |
| `index.ts` | Expo entry that registers the root component |
| `App.tsx` | Providers (gesture handler, safe-area, theme, navigation) |
| `App.tsx` / `src/navigation/RootNavigator.tsx` | Auth-gated stack navigator |
| `src/screens/HomeScreen.tsx` | Landing screen, primary CTA, location display |
| `src/screens/LoginScreen.tsx` | Phone + OTP login |
| `src/screens/RideRequestScreen.tsx` | Confirm ride + fare estimate |
| `src/screens/RideTrackingScreen.tsx` | Live ride tracking |
| `src/screens/ProfileScreen.tsx` | Profile, payment methods, sign-out |
| `src/components/MapView.tsx` | `react-native-maps` wrapper with fallback |
| `src/components/FareEstimate.tsx` | Fetches and shows the fare quote |
| `src/components/RideCard.tsx` | Compact ride summary card |
| `src/store/authStore.ts` | Zustand auth state |
| `src/store/rideStore.ts` | Zustand ride state |
| `src/services/api.ts` | Singleton API client |
| `src/services/location.ts` | `expo-location` wrapper |
| `src/hooks/useLocation.ts` | React hook for live location |
| `src/utils/format.ts` | KES / phone / relative-time formatters |
| `src/theme/index.ts` | Design tokens (colors, spacing, radii, font sizes) |
| `src/types/index.ts` | Re-exports shared types |
| `assets/.gitkeep` | Keeps the assets dir tracked |
| `.env.example` | `EXPO_PUBLIC_*` placeholders |

## `apps/driver/` — Expo driver app (19)

| File | Purpose |
|------|---------|
| `package.json` | Expo, RN, navigation, Zustand, socket.io-client |
| `app.json` | Expo config (background-location permission for dispatch) |
| `babel.config.js` | Babel preset + reanimated plugin |
| `metro.config.js` | Monorepo-aware Metro config |
| `tsconfig.json` | TypeScript config and path aliases |
| `index.ts` | Expo entry |
| `App.tsx` | Providers (gesture, safe-area, theme, navigation) |
| `src/navigation/RootNavigator.tsx` | Auth-gated driver stack |
| `src/screens/OnlineToggleScreen.tsx` | Online/offline toggle, navigation hub |
| `src/screens/LoginScreen.tsx` | Phone + OTP login |
| `src/screens/RideOfferScreen.tsx` | Accept/decline incoming ride offer with timer |
| `src/screens/EarningsScreen.tsx` | Today / week / lifetime earnings + recent trips |
| `src/screens/ProfileScreen.tsx` | Driver profile, rating, sign-out |
| `src/store/driverStore.ts` | Zustand state for session, profile, online toggle |
| `src/services/api.ts` | Singleton API client |
| `src/services/location.ts` | Foreground location stream |
| `src/theme/index.ts` | Dark theme tokens |
| `assets/.gitkeep` | Tracks the assets directory |
| `.env.example` | `EXPO_PUBLIC_*` placeholders |

## `apps/admin/` — Next.js admin dashboard (22)

| File | Purpose |
|------|---------|
| `package.json` | Next 14, React 18, Tailwind, socket.io-client |
| `next.config.js` | Strict mode, transpile shared packages |
| `tsconfig.json` | Extends base, adds Next plugin |
| `next-env.d.ts` | Next.js type reference |
| `tailwind.config.js` | Tailwind config with `brand` palette |
| `postcss.config.js` | Tailwind + Autoprefixer |
| `styles/globals.css` | Tailwind directives + utility classes |
| `pages/_app.tsx` | App wrapper with `<Layout>` |
| `pages/index.tsx` | Operations dashboard (5 stat cards) |
| `pages/login.tsx` | Admin email + password login |
| `pages/rides.tsx` | Latest rides table |
| `pages/drivers.tsx` | Drivers table |
| `pages/users.tsx` | Users table |
| `pages/payouts.tsx` | Payouts table |
| `pages/api/auth/[...nextauth].ts` | Auth endpoint stub (replaced in a follow-up commit) |
| `components/Layout.tsx` | Sidebar + main shell |
| `components/Sidebar.tsx` | Operations nav |
| `components/StatCard.tsx` | Accent-coloured KPI card |
| `components/RideTable.tsx` | Rides table |
| `lib/api.ts` | Singleton API client |
| `.env.example` | `NEXT_PUBLIC_*` placeholders |

## `services/api/` — Fastify backend (32)

| File | Purpose |
|------|---------|
| `package.json` | Fastify, Prisma, JWT, CORS, Helmet, rate-limit, Socket.IO, Zod, bcrypt |
| `tsconfig.json` | ESM, Node types, path aliases |
| `vitest.config.ts` | Vitest setup with path aliases |
| `prisma/schema.prisma` | `User`, `AdminUser`, `Driver`, `Place`, `Ride`, `Payment`, `Payout` models |
| `src/index.ts` | Bootstraps the Fastify server |
| `src/server.ts` | Wires CORS, helmet, JWT, rate-limit, Socket.IO, routes |
| `src/config/env.ts` | Zod-validated env loader |
| `src/config/db.ts` | Singleton Prisma client |
| `src/config/pricing.ts` | City pricing matrix (Nairobi, Mombasa, Kisumu) |
| `src/middleware/auth.ts` | `requireAuth`, `requireRole(...)` |
| `src/middleware/errorHandler.ts` | Central error handler (Zod → 400) |
| `src/routes/auth.ts` | `/auth/request-otp`, `/auth/verify-otp`, `/auth/admin/login`, `/auth/refresh` |
| `src/routes/rides.ts` | `/rides/quote`, `/rides/request`, `/rides/:id/cancel`, etc. |
| `src/routes/drivers.ts` | `/drivers/location`, `/drivers/online`, `/drivers/apply`, `/drivers/earnings` |
| `src/routes/users.ts` | `/users/me`, `/users/me` (PATCH) |
| `src/routes/payments.ts` | `/payments/mpesa/stk-push`, `/payments/mpesa/b2c`, `/payments/mpesa/callback` |
| `src/routes/admin.ts` | `/admin/stats`, `/admin/rides`, `/admin/drivers`, `/admin/users`, `/admin/payouts` |
| `src/controllers/authController.ts` | OTP + admin login logic |
| `src/controllers/rideController.ts` | Request, cancel, accept, complete, list, history |
| `src/controllers/driverController.ts` | Apply, set online, update location, list, earnings |
| `src/controllers/adminController.ts` | Dashboard stats, list rides/drivers/users/payouts, approve driver |
| `src/controllers/paymentController.ts` | STK push, B2C payout, Daraja callback |
| `src/services/fareCalculator.ts` | Pure quote function (base + per-km + per-minute + surge) |
| `src/services/rideMatching.ts` | Nearest-online-driver dispatch |
| `src/services/mpesa.ts` | Safaricom Daraja wrapper (STK push + B2C) |
| `src/services/sms.ts` | Africa's Talking OTP delivery |
| `src/sockets/index.ts` | Socket.IO channels + in-memory driver location store |
| `src/utils/logger.ts` | Pino logger (pretty in dev) |
| `src/utils/geo.ts` | Haversine distance |
| `src/types/index.ts` | Re-exports shared types |
| `tests/ride.test.ts` | Fare calculator unit tests |
| `.env.example` | All backend env vars (placeholders only) |

## `packages/` — Shared workspaces (11)

| File | Purpose |
|------|---------|
| `packages/shared-types/package.json` | Package manifest |
| `packages/shared-types/tsconfig.json` | TS config |
| `packages/shared-types/src/index.ts` | `User`, `Ride`, `DriverProfile`, `Session`, `Quote`, `DashboardStats`, … |
| `packages/shared-utils/package.json` | Package manifest |
| `packages/shared-utils/tsconfig.json` | TS config |
| `packages/shared-utils/src/index.ts` | `formatKsh`, `formatKenyanPhone`, `isValidKenyanPhone`, `haversineKm`, `relativeTime`, `clamp` |
| `packages/shared-utils/src/i18n/en.ts` | English copy |
| `packages/shared-utils/src/i18n/sw.ts` | Swahili copy |
| `packages/api-client/package.json` | Package manifest |
| `packages/api-client/tsconfig.json` | TS config |
| `packages/api-client/src/index.ts` | Typed `createApiClient({ baseUrl })` factory |

## Top-level extras added with the initial commit

| File | Purpose |
|------|---------|
| `repo-file-map.txt` | Visual directory tree (124 files) |
| `MANIFEST.md` | This file — per-file purpose table |

**Total: 124 files**, all source or configuration. No binaries, no node_modules,
no Docker artefacts, no real secrets — every credential in `.env.example` files
is `replace-me` and every other value is a `localhost` URL, a sandbox default
(`MPESA_SHORTCODE=174379`), or non-secret configuration.