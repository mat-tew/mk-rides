# MK RIDES

A modern, mobile-first ride-hailing platform built for Kenya. MK RIDES connects
passengers with drivers through three first-class experiences:

- **Passenger App** (`apps/passenger`) — request rides, track drivers in real time,
  pay via M-Pesa, and review trips.
- **Driver App** (`apps/driver`) — go online, accept ride offers, navigate to
  pickup, and track earnings.
- **Admin Dashboard** (`apps/admin`) — operations team tooling for ride
  monitoring, driver onboarding, payouts, and incident response.

The platform is designed around the Kenyan market: M-Pesa payments, low-bandwidth
optimised mobile clients, Swahili / English localisation, and a pricing model
that supports Nairobi, Mombasa, Kisumu and other urban centres.

## Repository layout

```
mk-rides/
├── apps/
│   ├── passenger/      # Expo React Native app for riders
│   ├── driver/         # Expo React Native app for drivers
│   └── admin/          # Next.js admin dashboard
├── services/
│   └── api/            # Fastify + TypeScript backend
└── packages/
    ├── shared-types/   # Cross-app domain types
    ├── shared-utils/   # Currency, geo, validators
    └── api-client/     # Typed HTTP/Socket client
```

## Tech stack

| Layer            | Choice                                                  |
|------------------|---------------------------------------------------------|
| Passenger app    | Expo (React Native), TypeScript, Zustand                |
| Driver app       | Expo (React Native), TypeScript, Zustand                |
| Admin dashboard  | Next.js 14, React 18, Tailwind CSS                      |
| Backend API      | Fastify, TypeScript, Prisma, PostgreSQL + PostGIS       |
| Real-time        | Socket.IO (ride dispatch, location stream)              |
| Payments         | Safaricom Daraja (M-Pesa STK Push & B2C)                |
| Maps             | React Native Maps (Google) / MapLibre in admin          |
| Auth             | JWT access + refresh, bcrypt password hashing           |
| Testing          | Vitest (backend), Jest (mobile)                         |

## Requirements

- Node.js >= 20 (`.nvmrc`)
- npm >= 10 (or pnpm >= 9)
- PostgreSQL 14+ with the PostGIS extension for geospatial queries
- Expo CLI for mobile development (`npx expo`)

No Docker is required to develop or run MK RIDES locally — the apps and backend
run directly on the host with a local Postgres instance.

## Getting started

```bash
# 1. Install all workspace dependencies
npm install

# 2. Configure environment variables (copy and edit per workspace)
cp services/api/.env.example services/api/.env
cp apps/admin/.env.example apps/admin/.env.local

# 3. Initialise the database (requires Postgres + PostGIS running)
npm run db:push -w services/api

# 4. Run the backend
npm run dev -w services/api

# 5. Run the admin dashboard
npm run dev -w apps/admin

# 6. Run the passenger or driver app (Expo)
npm run start -w apps/passenger
npm run start -w apps/driver
```

## Environment variables

Secrets are **never** committed. Each workspace ships a `.env.example` listing
the variables it expects (e.g. `MPESA_CONSUMER_KEY`, `JWT_SECRET`,
`DATABASE_URL`). Copy the example to `.env` / `.env.local` and fill in real
values from your local secret manager — production credentials live in a
dedicated secret store, not in this repository.

## Scripts

| Script                            | What it does                            |
|-----------------------------------|-----------------------------------------|
| `npm run dev -w services/api`     | Start the API on http://localhost:4000  |
| `npm run dev -w apps/admin`       | Start the admin dashboard on :3000      |
| `npm run start -w apps/passenger` | Launch Expo for the passenger app       |
| `npm run start -w apps/driver`    | Launch Expo for the driver app          |
| `npm run test`                    | Run all unit tests across workspaces    |
| `npm run lint`                    | Lint everything with ESLint + Prettier  |
| `npm run typecheck`               | Type-check every workspace              |

## Kenya-specific notes

- **Currency**: all monetary amounts are stored in KES (cents-precise integer).
- **Phone numbers**: validated against Kenyan formats (`+2547XXXXXXXX`,
  `07XXXXXXXX`).
- **Payments**: M-Pesa STK Push via Daraja, with C2B callback handling for
  wallet top-ups and B2C for driver payouts.
- **Localisation**: English and Swahili strings live in
  `packages/shared-utils/i18n/`.
- **Pricing**: base fare, per-km and per-minute rates, plus a Nairobi / Mombasa
  / Kisumu surcharge matrix in `services/api/src/config/pricing.ts`.

## License

MIT — see `LICENSE`.