# Security policy

## Reporting a vulnerability

If you discover a security issue in MK RIDES, please email
**security@mkrides.co.ke** rather than opening a public GitHub issue.
Include a description of the issue, steps to reproduce, and the impact
you believe it has.

We aim to acknowledge new reports within 2 business days and to ship a
fix or mitigation within 30 days for critical issues.

## Secrets

This repository **never** contains real credentials. Each workspace
ships a `.env.example` listing the variables it expects (e.g.
`MPESA_CONSUMER_KEY`, `JWT_SECRET`). Copy the example to `.env` /
`.env.local` (gitignored) and fill in real values from your local
secret manager.

Rotation policy for the operations team:

| Secret                      | Rotation       |
|-----------------------------|----------------|
| `JWT_SECRET`                | every 30 days  |
| `MPESA_CONSUMER_KEY`        | every 90 days  |
| `MPESA_B2C_SECURITY_CREDENTIAL` | every 90 days |
| Database credentials        | every 90 days  |