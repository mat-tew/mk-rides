import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { useAuthStore } from '../store/authStore';
import { LoginScreen } from '../screens/LoginScreen';
import { HomeScreen } from '../screens/HomeScreen';
import { RideRequestScreen } from '../screens/RideRequestScreen';
import { RideTrackingScreen } from '../screens/RideTrackingScreen';
import { ProfileScreen } from '../screens/ProfileScreen';
import { theme } from '../theme';

export type RootStackParamList = {
  Login: undefined;
  Home: undefined;
  RideRequest: { pickupId: string; dropoffId: string };
  RideTracking: { rideId: string };
  Profile: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export function RootNavigator() {
  const session = useAuthStore((s) => s.session);

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: theme.colors.brand },
          headerTintColor: theme.colors.textInverse,
          headerTitleStyle: { fontWeight: '600' },
        }}
      >
        {session ? (
          <>
            <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'MK RIDES' }} />
            <Stack.Screen name="RideRequest" component={RideRequestScreen} options={{ title: 'Confirm ride' }} />
            <Stack.Screen name="RideTracking" component={RideTrackingScreen} options={{ title: 'Your ride' }} />
            <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: 'Profile' }} />
          </>
        ) : (
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}