import { useCallback, useEffect, useState } from 'react';

import { locationService, type LocationFix } from '../services/location';

interface UseLocationResult {
  coords: LocationFix | null;
  error: string | null;
  requestPermission: () => Promise<void>;
}

/**
 * Tracks the device's foreground location. Components consuming this hook
 * are automatically unsubscribed on unmount.
 */
export function useLocation(): UseLocationResult {
  const [coords, setCoords] = useState<LocationFix | null>(null);
  const [error, setError] = useState<string | null>(null);

  const requestPermission = useCallback(async () => {
    try {
      const fix = await locationService.current();
      if (fix) setCoords(fix);
      else setError('Permission denied');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Location unavailable');
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    let unsubscribe: (() => void) | undefined;

    locationService
      .watch((fix) => {
        if (!cancelled) setCoords(fix);
      })
      .then((dispose) => {
        if (cancelled) dispose();
        else unsubscribe = dispose;
      });

    return () => {
      cancelled = true;
      unsubscribe?.();
    };
  }, []);

  return { coords, error, requestPermission };
}