// Re-export shared types for convenience inside the passenger app.
export * from '@mk-rides/shared-types';