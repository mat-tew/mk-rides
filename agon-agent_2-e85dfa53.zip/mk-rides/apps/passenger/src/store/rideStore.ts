import { create } from 'zustand';

import type { Ride } from '@mk-rides/shared-types';
import { api } from '../services/api';

interface RideState {
  activeRide: Ride | null;
  history: Ride[];
  requestRide: (pickupId: string, dropoffId: string) => Promise<Ride>;
  cancelRide: (rideId: string) => Promise<void>;
  loadHistory: () => Promise<void>;
}

export const useRideStore = create<RideState>((set) => ({
  activeRide: null,
  history: [],
  requestRide: async (pickupId, dropoffId) => {
    const ride = await api.requestRide({ pickupId, dropoffId });
    set({ activeRide: ride });
    return ride;
  },
  cancelRide: async (rideId) => {
    await api.cancelRide(rideId);
    set((state) => (state.activeRide?.id === rideId ? { activeRide: null } : {}));
  },
  loadHistory: async () => {
    const rides = await api.rideHistory();
    set({ history: rides });
  },
}));