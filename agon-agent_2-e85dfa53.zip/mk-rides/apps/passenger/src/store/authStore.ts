import { create } from 'zustand';

import { api } from '../services/api';
import type { Session, User } from '@mk-rides/shared-types';

interface AuthState {
  session: Session | null;
  loading: boolean;
  error: string | null;
  requestOtp: (phone: string) => Promise<void>;
  verifyOtp: (phone: string, code: string) => Promise<void>;
  signOut: () => void;
}

/**
 * Authentication store. Backed by the API client and persisted to
 * SecureStore in a follow-up commit; for the initial commit we keep
 * state in memory and re-hydrate on app launch via `bootstrap`.
 */
export const useAuthStore = create<AuthState>((set) => ({
  session: null,
  loading: false,
  error: null,
  requestOtp: async (phone: string) => {
    set({ loading: true, error: null });
    try {
      await api.requestOtp({ phone });
      set({ loading: false });
    } catch (err) {
      set({ loading: false, error: (err as Error).message });
      throw err;
    }
  },
  verifyOtp: async (phone: string, code: string) => {
    set({ loading: true, error: null });
    try {
      const session = await api.verifyOtp({ phone, code });
      set({ session, loading: false });
    } catch (err) {
      set({ loading: false, error: (err as Error).message });
      throw err;
    }
  },
  signOut: () => set({ session: null }),
}));

export type { User };