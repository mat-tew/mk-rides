import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, ActivityIndicator } from 'react-native';

import { useAuthStore } from '../store/authStore';
import { theme } from '../theme';

/**
 * Phone + OTP login. In production the OTP is delivered via Africa's Talking
 * or a similar SMS provider; here we hit the local `/auth/request-otp` and
 * `/auth/verify-otp` endpoints on the MK RIDES backend.
 */
export function LoginScreen() {
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [stage, setStage] = useState<'phone' | 'code'>('phone');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const requestOtp = useAuthStore((s) => s.requestOtp);
  const verifyOtp = useAuthStore((s) => s.verifyOtp);

  const handleRequest = async () => {
    setError(null);
    setLoading(true);
    try {
      await requestOtp(phone);
      setStage('code');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send code');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setError(null);
    setLoading(true);
    try {
      await verifyOtp(phone, code);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid code');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>MK RIDES</Text>
      <Text style={styles.subtitle}>Sign in to ride across Kenya</Text>

      {stage === 'phone' ? (
        <>
          <Text style={styles.label}>Phone number</Text>
          <TextInput
            style={styles.input}
            placeholder="0712 345 678"
            keyboardType="phone-pad"
            value={phone}
            onChangeText={setPhone}
            autoComplete="tel"
          />
          <Pressable style={styles.button} onPress={handleRequest} disabled={loading || phone.length < 9}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Send code</Text>}
          </Pressable>
        </>
      ) : (
        <>
          <Text style={styles.label}>Enter the 6-digit code sent to {phone}</Text>
          <TextInput
            style={styles.input}
            placeholder="123456"
            keyboardType="number-pad"
            value={code}
            onChangeText={setCode}
            maxLength={6}
          />
          <Pressable style={styles.button} onPress={handleVerify} disabled={loading || code.length !== 6}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Verify</Text>}
          </Pressable>
          <Pressable onPress={() => setStage('phone')}>
            <Text style={styles.link}>Change number</Text>
          </Pressable>
        </>
      )}

      {error && <Text style={styles.error}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: theme.spacing.xl, backgroundColor: theme.colors.brand, justifyContent: 'center' },
  title: { fontSize: theme.fontSize.display, fontWeight: '800', color: theme.colors.textInverse, textAlign: 'center' },
  subtitle: { fontSize: theme.fontSize.md, color: '#CCFBF1', textAlign: 'center', marginBottom: theme.spacing.xl },
  label: { color: '#CCFBF1', marginBottom: theme.spacing.sm },
  input: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.radius.md,
    padding: theme.spacing.md,
    fontSize: theme.fontSize.md,
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  button: {
    backgroundColor: theme.colors.accent,
    padding: theme.spacing.md,
    borderRadius: theme.radius.md,
    alignItems: 'center',
  },
  buttonText: { color: theme.colors.text, fontWeight: '700', fontSize: theme.fontSize.md },
  link: { color: '#CCFBF1', textAlign: 'center', marginTop: theme.spacing.md },
  error: { color: '#FECACA', marginTop: theme.spacing.md, textAlign: 'center' },
});