import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { theme } from '../theme';
import { FareEstimate } from '../components/FareEstimate';
import type { RootStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'RideRequest'>;

/**
 * Confirmation screen shown after the passenger selects pickup & dropoff.
 * The map preview and fare estimate are populated from the route params
 * and the fare calculator in `services/api`.
 */
export function RideRequestScreen({ route }: Props) {
  const { pickupId, dropoffId } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Confirm your ride</Text>
      <Text style={styles.row}>
        <Text style={styles.label}>Pickup: </Text>
        {pickupId}
      </Text>
      <Text style={styles.row}>
        <Text style={styles.label}>Dropoff: </Text>
        {dropoffId}
      </Text>

      <FareEstimate pickupId={pickupId} dropoffId={dropoffId} />

      <Text style={styles.note}>
        By tapping Confirm you agree to MK RIDES' terms of service and the standard
        cancellation policy.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: theme.spacing.lg, backgroundColor: theme.colors.background },
  title: { fontSize: theme.fontSize.xl, fontWeight: '700', color: theme.colors.text, marginBottom: theme.spacing.md },
  row: { fontSize: theme.fontSize.md, color: theme.colors.text, marginBottom: theme.spacing.sm },
  label: { fontWeight: '600', color: theme.colors.textMuted },
  note: { marginTop: theme.spacing.lg, fontSize: theme.fontSize.sm, color: theme.colors.textMuted },
});