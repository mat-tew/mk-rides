import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';

import { useAuthStore } from '../store/authStore';
import { theme } from '../theme';

export function ProfileScreen() {
  const session = useAuthStore((s) => s.session);
  const signOut = useAuthStore((s) => s.signOut);

  return (
    <View style={styles.container}>
      <Text style={styles.name}>{session?.user?.name ?? 'Rider'}</Text>
      <Text style={styles.phone}>{session?.user?.phone ?? ''}</Text>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Saved payment methods</Text>
        <Text style={styles.cardBody}>M-Pesa (•••• {session?.user?.mpesaSuffix ?? '0000'})</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Ride history</Text>
        <Text style={styles.cardBody}>Tap to view your last 30 rides</Text>
      </View>

      <Pressable style={styles.signOut} onPress={signOut}>
        <Text style={styles.signOutText}>Sign out</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: theme.spacing.lg, backgroundColor: theme.colors.background },
  name: { fontSize: theme.fontSize.xxl, fontWeight: '700', color: theme.colors.text },
  phone: { color: theme.colors.textMuted, marginBottom: theme.spacing.lg },
  card: {
    backgroundColor: theme.colors.surface,
    padding: theme.spacing.md,
    borderRadius: theme.radius.md,
    marginBottom: theme.spacing.md,
  },
  cardTitle: { fontWeight: '600', color: theme.colors.text },
  cardBody: { color: theme.colors.textMuted, marginTop: theme.spacing.xs },
  signOut: {
    marginTop: theme.spacing.xl,
    padding: theme.spacing.md,
    alignItems: 'center',
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.surfaceMuted,
  },
  signOutText: { color: theme.colors.danger, fontWeight: '600' },
});