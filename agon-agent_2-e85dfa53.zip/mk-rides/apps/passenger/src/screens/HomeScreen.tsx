import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { useLocation } from '../hooks/useLocation';
import { theme } from '../theme';
import type { RootStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'Home'>;

/**
 * Landing screen after login. Shows the user's current location, a primary
 * "Where to?" CTA, and quick links to recent destinations.
 */
export function HomeScreen({ navigation }: Props) {
  const { coords, error, requestPermission } = useLocation();

  useEffect(() => {
    requestPermission();
  }, [requestPermission]);

  return (
    <View style={styles.container}>
      <Text style={styles.greeting}>Good day 👋</Text>
      <Text style={styles.subtitle}>Where are we taking you today?</Text>

      <Pressable
        accessibilityRole="button"
        style={styles.cta}
        onPress={() =>
          navigation.navigate('RideRequest', { pickupId: 'current', dropoffId: 'pending' })
        }
      >
        <Text style={styles.ctaText}>Where to?</Text>
      </Pressable>

      {error ? (
        <Text style={styles.error}>Location: {error}</Text>
      ) : coords ? (
        <Text style={styles.location}>
          You are at {coords.latitude.toFixed(4)}, {coords.longitude.toFixed(4)}
        </Text>
      ) : (
        <Text style={styles.location}>Locating you…</Text>
      )}

      <Pressable style={styles.link} onPress={() => navigation.navigate('Profile')}>
        <Text style={styles.linkText}>View profile</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: theme.spacing.lg, backgroundColor: theme.colors.background },
  greeting: { fontSize: theme.fontSize.xxl, fontWeight: '700', color: theme.colors.text },
  subtitle: { fontSize: theme.fontSize.md, color: theme.colors.textMuted, marginTop: theme.spacing.sm },
  cta: {
    marginTop: theme.spacing.xl,
    paddingVertical: theme.spacing.lg,
    paddingHorizontal: theme.spacing.xl,
    borderRadius: theme.radius.lg,
    backgroundColor: theme.colors.brand,
    alignItems: 'center',
  },
  ctaText: { color: theme.colors.textInverse, fontSize: theme.fontSize.lg, fontWeight: '600' },
  location: { marginTop: theme.spacing.lg, color: theme.colors.textMuted },
  error: { marginTop: theme.spacing.lg, color: theme.colors.danger },
  link: { marginTop: theme.spacing.xl, alignItems: 'center' },
  linkText: { color: theme.colors.brand, fontWeight: '600' },
});