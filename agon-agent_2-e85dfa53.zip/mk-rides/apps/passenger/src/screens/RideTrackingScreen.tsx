import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { theme } from '../theme';
import type { RootStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'RideTracking'>;

/**
 * Live tracking screen. Driver location is streamed via Socket.IO from
 * `services/api` and rendered on the map. The screen also surfaces the
 * driver's name, plate, photo, and ETA.
 */
export function RideTrackingScreen({ route }: Props) {
  const { rideId } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Ride {rideId}</Text>
      <Text style={styles.subtitle}>Your driver is on the way</Text>
      <Text style={styles.body}>
        Real-time tracking uses Socket.IO channels keyed by ride ID. Driver
        location, status updates and ETA refresh every 5 seconds.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: theme.spacing.lg, backgroundColor: theme.colors.background },
  title: { fontSize: theme.fontSize.xl, fontWeight: '700', color: theme.colors.text },
  subtitle: { fontSize: theme.fontSize.md, color: theme.colors.brand, marginTop: theme.spacing.sm },
  body: { marginTop: theme.spacing.lg, color: theme.colors.textMuted, lineHeight: 22 },
});