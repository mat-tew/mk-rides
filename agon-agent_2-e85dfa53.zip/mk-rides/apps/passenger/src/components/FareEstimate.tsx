import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';

import { api } from '../services/api';
import { theme } from '../theme';

interface FareEstimateProps {
  pickupId: string;
  dropoffId: string;
}

interface Quote {
  amountKsh: number;
  currency: 'KES';
  etaMinutes: number;
  distanceKm: number;
  surgeMultiplier: number;
}

const PLACEHOLDER: Quote = {
  amountKsh: 0,
  currency: 'KES',
  etaMinutes: 0,
  distanceKm: 0,
  surgeMultiplier: 1,
};

/**
 * Displays a fare quote from the backend. In production this streams updated
 * quotes when the user moves the pickup pin or the demand changes.
 */
export function FareEstimate({ pickupId, dropoffId }: FareEstimateProps) {
  const [quote, setQuote] = useState<Quote>(PLACEHOLDER);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .fareQuote({ pickupId, dropoffId })
      .then((data) => {
        if (!cancelled) setQuote(data);
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Quote failed');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [pickupId, dropoffId]);

  if (loading) return <ActivityIndicator color={theme.colors.brand} style={{ marginTop: theme.spacing.lg }} />;
  if (error) return <Text style={styles.error}>{error}</Text>;

  return (
    <View style={styles.container}>
      <Text style={styles.amount}>KES {quote.amountKsh.toLocaleString()}</Text>
      <Text style={styles.meta}>
        {quote.distanceKm.toFixed(1)} km • {quote.etaMinutes} min
        {quote.surgeMultiplier > 1 ? ` • ${quote.surgeMultiplier.toFixed(1)}x surge` : ''}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginTop: theme.spacing.lg, padding: theme.spacing.md, backgroundColor: theme.colors.surface, borderRadius: theme.radius.md },
  amount: { fontSize: theme.fontSize.xxl, fontWeight: '700', color: theme.colors.brand },
  meta: { color: theme.colors.textMuted, marginTop: theme.spacing.xs },
  error: { color: theme.colors.danger, marginTop: theme.spacing.md },
});