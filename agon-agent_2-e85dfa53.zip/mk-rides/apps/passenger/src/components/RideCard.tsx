import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

import type { Ride } from '@mk-rides/shared-types';
import { theme } from '../theme';

interface RideCardProps {
  ride: Ride;
}

/**
 * Compact card used in ride history and active-ride lists.
 */
export function RideCard({ ride }: RideCardProps) {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{ride.pickup.address} → {ride.dropoff.address}</Text>
      <Text style={styles.meta}>
        {new Date(ride.requestedAt).toLocaleString()} • KES {ride.fareKsh.toLocaleString()}
      </Text>
      <Text style={styles.status}>{ride.status.replace('_', ' ')}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { padding: theme.spacing.md, backgroundColor: theme.colors.surface, borderRadius: theme.radius.md, marginBottom: theme.spacing.sm },
  title: { fontWeight: '600', color: theme.colors.text },
  meta: { color: theme.colors.textMuted, marginTop: theme.spacing.xs, fontSize: theme.fontSize.sm },
  status: { color: theme.colors.brand, marginTop: theme.spacing.xs, fontSize: theme.fontSize.sm, fontWeight: '600' },
});