import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import MapViewRN, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';

import type { LatLng } from '@mk-rides/shared-types';
import { theme } from '../theme';

interface MapViewProps {
  center: LatLng;
  driver?: LatLng | null;
  pickup?: LatLng;
  dropoff?: LatLng;
}

/**
 * Thin wrapper around `react-native-maps`. In Expo Go we render a styled
 * placeholder so the app boots without a Google Maps API key; in dev/prod
 * builds we mount the real map component.
 */
export function MapView({ center, driver, pickup, dropoff }: MapViewProps) {
  // Placeholder when the native map module is not available (Expo Go).
  if (!MapViewRN) {
    return (
      <View style={[styles.fallback, { backgroundColor: theme.colors.surface }]}>
        <Text style={styles.fallbackText}>Map preview</Text>
        <Text style={styles.fallbackCoords}>
          {center.latitude.toFixed(4)}, {center.longitude.toFixed(4)}
        </Text>
      </View>
    );
  }

  return (
    <MapViewRN
      provider={PROVIDER_GOOGLE}
      style={styles.map}
      initialRegion={{
        latitude: center.latitude,
        longitude: center.longitude,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      }}
    >
      {pickup && <Marker coordinate={pickup} title="Pickup" />}
      {dropoff && <Marker coordinate={dropoff} title="Dropoff" pinColor={theme.colors.accent} />}
      {driver && <Marker coordinate={driver} title="Driver" pinColor={theme.colors.brand} />}
    </MapViewRN>
  );
}

const styles = StyleSheet.create({
  map: { flex: 1 },
  fallback: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  fallbackText: { fontSize: theme.fontSize.lg, color: theme.colors.textMuted },
  fallbackCoords: { color: theme.colors.textMuted, marginTop: theme.spacing.sm },
});