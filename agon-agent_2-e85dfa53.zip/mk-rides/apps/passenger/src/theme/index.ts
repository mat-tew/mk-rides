/**
 * MK RIDES design tokens.
 *
 * Centralised colours, spacing, typography and radii used across the
 * passenger app. Keeping these in one place makes it easy to align the
 * passenger and driver experiences and to support light/dark variants.
 */

export const theme = {
  colors: {
    brand: '#0F766E', // teal-700, the MK RIDES primary
    brandDark: '#0B5C56',
    accent: '#F59E0B', // amber-500, used for fares & CTAs
    success: '#16A34A',
    danger: '#DC2626',
    warning: '#F59E0B',
    info: '#2563EB',

    background: '#FFFFFF',
    surface: '#F8FAFC',
    surfaceMuted: '#F1F5F9',
    border: '#E2E8F0',

    text: '#0F172A',
    textMuted: '#475569',
    textInverse: '#FFFFFF',
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  radius: {
    sm: 4,
    md: 8,
    lg: 12,
    xl: 24,
    pill: 999,
  },
  fontSize: {
    xs: 12,
    sm: 14,
    md: 16,
    lg: 18,
    xl: 22,
    xxl: 28,
    display: 36,
  },
} as const;

export type Theme = typeof theme;