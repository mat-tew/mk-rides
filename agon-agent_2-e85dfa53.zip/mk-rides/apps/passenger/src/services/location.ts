import * as Location from 'expo-location';

import type { LatLng } from '@mk-rides/shared-types';

export interface LocationFix extends LatLng {
  accuracy: number;
  timestamp: number;
}

/**
 * Wraps `expo-location` so the rest of the app can request a single fix
 * or subscribe to a stream without dealing with permission semantics
 * directly. Permission UX lives in `hooks/useLocation.ts`.
 */
export const locationService = {
  async requestPermission(): Promise<boolean> {
    const { status } = await Location.requestForegroundPermissionsAsync();
    return status === 'granted';
  },

  async current(): Promise<LocationFix | null> {
    const ok = await this.requestPermission();
    if (!ok) return null;
    const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    return {
      latitude: pos.coords.latitude,
      longitude: pos.coords.longitude,
      accuracy: pos.coords.accuracy ?? 0,
      timestamp: pos.timestamp,
    };
  },

  async watch(onChange: (fix: LocationFix) => void): Promise<() => void> {
    const ok = await this.requestPermission();
    if (!ok) return () => undefined;
    const sub = await Location.watchPositionAsync(
      { accuracy: Location.Accuracy.High, distanceInterval: 10 },
      (pos) =>
        onChange({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy ?? 0,
          timestamp: pos.timestamp,
        }),
    );
    return () => sub.remove();
  },
};