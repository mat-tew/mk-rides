import { createApiClient } from '@mk-rides/api-client';

const baseUrl = process.env.EXPO_PUBLIC_API_BASE_URL ?? 'http://localhost:4000';

/**
 * Singleton API client used throughout the passenger app. Backed by the
 * shared `@mk-rides/api-client` package which wraps fetch with auth
 * headers, JSON encoding and a typed surface for every backend route.
 */
export const api = createApiClient({ baseUrl });