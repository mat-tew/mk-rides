import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

import { RootNavigator } from './src/navigation/RootNavigator';
import { theme } from './src/theme';

/**
 * Root of the MK RIDES passenger app.
 *
 * Sets up safe-area + gesture handler providers, the navigation tree,
 * and the global theme. Authentication state is managed by `authStore`
 * and consumed by the RootNavigator.
 */
export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar style="light" backgroundColor={theme.colors.brand} />
        <RootNavigator />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}