import { createApiClient } from '@mk-rides/api-client';

const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:4000';

/**
 * Server + browser-safe API client. In Next.js, `process.env.*` on the
 * client is replaced at build time with `NEXT_PUBLIC_*` values.
 */
export const api = createApiClient({ baseUrl });