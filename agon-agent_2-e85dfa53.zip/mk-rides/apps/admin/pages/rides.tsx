import { useEffect, useState } from 'react';

import { RideTable } from '../components/RideTable';
import { api } from '../lib/api';
import type { Ride } from '@mk-rides/shared-types';

export default function RidesPage() {
  const [rides, setRides] = useState<Ride[]>([]);

  useEffect(() => {
    api
      .listRides({ limit: 50 })
      .then((data) => setRides(data.rides))
      .catch(() => undefined);
  }, []);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Rides</h1>
      <p className="text-sm text-slate-500">
        Latest 50 rides. Use filters to narrow by status, date, city, or driver.
      </p>
      <RideTable rides={rides} />
    </div>
  );
}