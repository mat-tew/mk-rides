import { useEffect, useState } from 'react';

import { api } from '../lib/api';
import type { DriverProfile } from '@mk-rides/shared-types';

export default function DriversPage() {
  const [drivers, setDrivers] = useState<DriverProfile[]>([]);

  useEffect(() => {
    api
      .listDrivers({ limit: 100 })
      .then((data) => setDrivers(data.drivers))
      .catch(() => undefined);
  }, []);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Drivers</h1>
      <div className="mkr-card overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="text-left text-slate-500">
              <th className="py-2 pr-4">Name</th>
              <th className="py-2 pr-4">Vehicle</th>
              <th className="py-2 pr-4">Plate</th>
              <th className="py-2 pr-4">Rating</th>
              <th className="py-2 pr-4">Status</th>
            </tr>
          </thead>
          <tbody>
            {drivers.map((d) => (
              <tr key={d.id} className="border-t border-slate-200">
                <td className="py-2 pr-4 font-medium">{d.name}</td>
                <td className="py-2 pr-4">{d.vehicle?.model ?? '—'}</td>
                <td className="py-2 pr-4">{d.vehicle?.plate ?? '—'}</td>
                <td className="py-2 pr-4">{d.rating.toFixed(2)} ⭐</td>
                <td className="py-2 pr-4">{d.verificationStatus}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}