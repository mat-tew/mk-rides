import { useEffect, useState } from 'react';

import { api } from '../lib/api';
import type { Payout } from '@mk-rides/shared-types';

export default function PayoutsPage() {
  const [payouts, setPayouts] = useState<Payout[]>([]);

  useEffect(() => {
    api
      .listPayouts({ limit: 100 })
      .then((data) => setPayouts(data.payouts))
      .catch(() => undefined);
  }, []);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Payouts</h1>
      <div className="mkr-card overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="text-left text-slate-500">
              <th className="py-2 pr-4">Driver</th>
              <th className="py-2 pr-4">Amount (KES)</th>
              <th className="py-2 pr-4">Status</th>
              <th className="py-2 pr-4">Initiated</th>
            </tr>
          </thead>
          <tbody>
            {payouts.map((p) => (
              <tr key={p.id} className="border-t border-slate-200">
                <td className="py-2 pr-4">{p.driverName}</td>
                <td className="py-2 pr-4">{p.amountKsh.toLocaleString()}</td>
                <td className="py-2 pr-4">{p.status}</td>
                <td className="py-2 pr-4">{new Date(p.initiatedAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}