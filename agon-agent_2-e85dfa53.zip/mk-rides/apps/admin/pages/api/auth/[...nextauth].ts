import type { NextApiRequest, NextApiResponse } from 'next';

/**
 * Placeholder NextAuth-style endpoint. The first commit ships a stub so
 * that `next build` succeeds and the dashboard renders. A future commit
 * replaces this with the real NextAuth configuration (Credentials
 * provider against the admin login endpoint on services/api).
 */
export default function handler(req: NextApiRequest, res: NextApiResponse) {
  res.status(501).json({ error: 'Authentication is not configured in this commit.' });
}