import { useEffect, useState } from 'react';

import { StatCard } from '../components/StatCard';
import { api } from '../lib/api';
import type { DashboardStats } from '@mk-rides/shared-types';

const PLACEHOLDER: DashboardStats = {
  activeRides: 0,
  onlineDrivers: 0,
  ridesToday: 0,
  revenueTodayKsh: 0,
  pendingVerifications: 0,
};

export default function Home() {
  const [stats, setStats] = useState<DashboardStats>(PLACEHOLDER);

  useEffect(() => {
    api
      .dashboardStats()
      .then(setStats)
      .catch(() => undefined);
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Operations dashboard</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <StatCard label="Active rides" value={stats.activeRides} accent="brand" />
        <StatCard label="Online drivers" value={stats.onlineDrivers} accent="green" />
        <StatCard label="Rides today" value={stats.ridesToday} accent="blue" />
        <StatCard
          label="Revenue today"
          value={`KES ${stats.revenueTodayKsh.toLocaleString()}`}
          accent="amber"
        />
        <StatCard label="Pending verifications" value={stats.pendingVerifications} accent="red" />
      </div>

      <p className="text-sm text-slate-500">
        Real-time data via the MK RIDES backend. Refreshes every 30 seconds.
      </p>
    </div>
  );
}