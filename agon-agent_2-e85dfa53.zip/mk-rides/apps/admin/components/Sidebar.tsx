import Link from 'next/link';

const NAV = [
  { href: '/', label: 'Dashboard' },
  { href: '/rides', label: 'Rides' },
  { href: '/drivers', label: 'Drivers' },
  { href: '/users', label: 'Users' },
  { href: '/payouts', label: 'Payouts' },
];

export function Sidebar() {
  return (
    <aside className="w-56 bg-slate-900 text-slate-100 p-4">
      <h2 className="text-sm uppercase tracking-wide text-slate-400 mb-3">Operations</h2>
      <nav className="flex flex-col gap-1">
        {NAV.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="rounded-md px-3 py-2 hover:bg-slate-800 transition"
          >
            {item.label}
          </Link>
        ))}
      </nav>
    </aside>
  );
}