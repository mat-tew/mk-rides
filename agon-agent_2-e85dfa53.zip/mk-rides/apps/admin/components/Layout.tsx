import React from 'react';
import Link from 'next/link';

import { Sidebar } from './Sidebar';

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex">
      <Sidebar />
      <main className="flex-1 p-6 bg-slate-50">
        <header className="mb-6 flex items-center justify-between">
          <Link href="/" className="text-lg font-bold text-brand-700">
            MK RIDES Admin
          </Link>
          <span className="text-sm text-slate-500">v0.1.0 • dev</span>
        </header>
        {children}
      </main>
    </div>
  );
}