import type { Ride } from '@mk-rides/shared-types';

export function RideTable({ rides }: { rides: Ride[] }) {
  return (
    <div className="mkr-card overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="text-left text-slate-500">
            <th className="py-2 pr-4">Ride ID</th>
            <th className="py-2 pr-4">Pickup</th>
            <th className="py-2 pr-4">Dropoff</th>
            <th className="py-2 pr-4">Fare (KES)</th>
            <th className="py-2 pr-4">Status</th>
            <th className="py-2 pr-4">Requested</th>
          </tr>
        </thead>
        <tbody>
          {rides.map((r) => (
            <tr key={r.id} className="border-t border-slate-200">
              <td className="py-2 pr-4 font-mono text-xs">{r.id}</td>
              <td className="py-2 pr-4">{r.pickup.address}</td>
              <td className="py-2 pr-4">{r.dropoff.address}</td>
              <td className="py-2 pr-4">{r.fareKsh.toLocaleString()}</td>
              <td className="py-2 pr-4">{r.status.replace('_', ' ')}</td>
              <td className="py-2 pr-4">{new Date(r.requestedAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}