import clsx from 'clsx';

interface StatCardProps {
  label: string;
  value: number | string;
  accent?: 'brand' | 'green' | 'blue' | 'amber' | 'red';
}

const ACCENTS: Record<NonNullable<StatCardProps['accent']>, string> = {
  brand: 'border-brand-500',
  green: 'border-green-500',
  blue: 'border-blue-500',
  amber: 'border-amber-500',
  red: 'border-red-500',
};

export function StatCard({ label, value, accent = 'brand' }: StatCardProps) {
  return (
    <div className={clsx('mkr-card border-l-4', ACCENTS[accent])}>
      <p className="text-sm text-slate-500">{label}</p>
      <p className="mt-2 text-2xl font-bold text-slate-900">{value}</p>
    </div>
  );
}