/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ['@mk-rides/api-client', '@mk-rides/shared-types', '@mk-rides/shared-utils'],
  experimental: {
    typedRoutes: true,
  },
};

module.exports = nextConfig;