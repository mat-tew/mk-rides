export const theme = {
  colors: {
    brand: '#0F172A',
    brandDark: '#020617',
    accent: '#22C55E',
    success: '#16A34A',
    danger: '#DC2626',
    warning: '#F59E0B',
    info: '#2563EB',
    background: '#0F172A',
    surface: '#1E293B',
    surfaceMuted: '#334155',
    border: '#475569',
    text: '#F8FAFC',
    textMuted: '#94A3B8',
    textInverse: '#0F172A',
  },
  spacing: { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 },
  radius: { sm: 4, md: 8, lg: 12, xl: 24, pill: 999 },
  fontSize: { xs: 12, sm: 14, md: 16, lg: 18, xl: 22, xxl: 28, display: 36 },
} as const;

export type Theme = typeof theme;