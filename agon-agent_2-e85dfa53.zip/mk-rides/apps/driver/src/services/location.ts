import * as Location from 'expo-location';

import type { LatLng } from '@mk-rides/shared-types';

export interface LocationFix extends LatLng {
  accuracy: number;
  timestamp: number;
}

export const driverLocationService = {
  async current(): Promise<LocationFix | null> {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') return null;
    const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
    return {
      latitude: pos.coords.latitude,
      longitude: pos.coords.longitude,
      accuracy: pos.coords.accuracy ?? 0,
      timestamp: pos.timestamp,
    };
  },

  async startStreaming(onFix: (fix: LocationFix) => void): Promise<() => void> {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') return () => undefined;
    const sub = await Location.watchPositionAsync(
      { accuracy: Location.Accuracy.High, timeInterval: 3000, distanceInterval: 5 },
      (pos) =>
        onFix({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy ?? 0,
          timestamp: pos.timestamp,
        }),
    );
    return () => sub.remove();
  },
};