import { createApiClient } from '@mk-rides/api-client';

const baseUrl = process.env.EXPO_PUBLIC_API_BASE_URL ?? 'http://localhost:4000';

export const api = createApiClient({ baseUrl });