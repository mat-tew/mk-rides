import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { useDriverStore } from '../store/driverStore';
import { LoginScreen } from '../screens/LoginScreen';
import { OnlineToggleScreen } from '../screens/OnlineToggleScreen';
import { RideOfferScreen } from '../screens/RideOfferScreen';
import { EarningsScreen } from '../screens/EarningsScreen';
import { ProfileScreen } from '../screens/ProfileScreen';
import { theme } from '../theme';

export type DriverStackParamList = {
  Login: undefined;
  OnlineToggle: undefined;
  RideOffer: { rideId: string };
  Earnings: undefined;
  Profile: undefined;
};

const Stack = createNativeStackNavigator<DriverStackParamList>();

export function RootNavigator() {
  const session = useDriverStore((s) => s.session);

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: theme.colors.brand },
          headerTintColor: theme.colors.text,
          headerTitleStyle: { fontWeight: '700' },
        }}
      >
        {session ? (
          <>
            <Stack.Screen name="OnlineToggle" component={OnlineToggleScreen} options={{ title: 'MK RIDES Driver' }} />
            <Stack.Screen name="RideOffer" component={RideOfferScreen} options={{ title: 'New ride offer' }} />
            <Stack.Screen name="Earnings" component={EarningsScreen} options={{ title: 'Earnings' }} />
            <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: 'Profile' }} />
          </>
        ) : (
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}