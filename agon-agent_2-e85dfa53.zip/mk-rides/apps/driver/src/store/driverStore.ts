import { create } from 'zustand';

import type { DriverProfile, Session } from '@mk-rides/shared-types';
import { api } from '../services/api';

interface DriverState {
  session: Session | null;
  profile: DriverProfile | null;
  isOnline: boolean;
  requestOtp: (phone: string) => Promise<void>;
  verifyOtp: (phone: string, code: string) => Promise<void>;
  toggleOnline: () => Promise<void>;
  signOut: () => void;
}

export const useDriverStore = create<DriverState>((set, get) => ({
  session: null,
  profile: null,
  isOnline: false,
  requestOtp: async (phone: string) => {
    await api.requestOtp({ phone });
  },
  verifyOtp: async (phone: string, code: string) => {
    const session = await api.verifyOtp({ phone, code, role: 'driver' });
    set({ session });
  },
  toggleOnline: async () => {
    const next = !get().isOnline;
    await api.setDriverOnline(next);
    set({ isOnline: next });
  },
  signOut: () => set({ session: null, profile: null, isOnline: false }),
}));