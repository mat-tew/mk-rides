import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { useDriverStore } from '../store/driverStore';
import { theme } from '../theme';
import type { DriverStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<DriverStackParamList, 'OnlineToggle'>;

/**
 * Driver home screen. A single big toggle takes the driver online or
 * offline. When online, the location stream is published to the backend
 * over Socket.IO and dispatch starts sending ride offers.
 */
export function OnlineToggleScreen({ navigation }: Props) {
  const isOnline = useDriverStore((s) => s.isOnline);
  const toggleOnline = useDriverStore((s) => s.toggleOnline);

  return (
    <View style={styles.container}>
      <Text style={styles.status}>{isOnline ? 'You are online' : 'You are offline'}</Text>
      <Text style={styles.subtitle}>
        {isOnline
          ? 'Ride offers will appear here. Stay safe on the road.'
          : 'Tap below to start receiving ride offers.'}
      </Text>

      <Pressable
        style={[styles.button, { backgroundColor: isOnline ? theme.colors.danger : theme.colors.accent }]}
        onPress={toggleOnline}
      >
        <Text style={styles.buttonText}>{isOnline ? 'Go offline' : 'Go online'}</Text>
      </Pressable>

      <View style={styles.row}>
        <Pressable style={styles.link} onPress={() => navigation.navigate('Earnings')}>
          <Text style={styles.linkText}>Earnings</Text>
        </Pressable>
        <Pressable style={styles.link} onPress={() => navigation.navigate('Profile')}>
          <Text style={styles.linkText}>Profile</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: theme.spacing.lg, backgroundColor: theme.colors.background, justifyContent: 'center' },
  status: { fontSize: theme.fontSize.xxl, fontWeight: '700', color: theme.colors.text, textAlign: 'center' },
  subtitle: { fontSize: theme.fontSize.md, color: theme.colors.textMuted, textAlign: 'center', marginTop: theme.spacing.sm },
  button: { marginTop: theme.spacing.xl, padding: theme.spacing.lg, borderRadius: theme.radius.lg, alignItems: 'center' },
  buttonText: { color: theme.colors.textInverse, fontWeight: '700', fontSize: theme.fontSize.lg },
  row: { flexDirection: 'row', justifyContent: 'space-around', marginTop: theme.spacing.xxl },
  link: { padding: theme.spacing.md },
  linkText: { color: theme.colors.text, fontWeight: '600' },
});