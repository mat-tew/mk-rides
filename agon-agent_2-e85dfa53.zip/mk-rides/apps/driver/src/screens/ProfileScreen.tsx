import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';

import { useDriverStore } from '../store/driverStore';
import { theme } from '../theme';

export function ProfileScreen() {
  const profile = useDriverStore((s) => s.profile);
  const signOut = useDriverStore((s) => s.signOut);

  return (
    <View style={styles.container}>
      <Text style={styles.name}>{profile?.name ?? 'Driver'}</Text>
      <Text style={styles.meta}>{profile?.vehicle?.plate ?? 'No vehicle on file'}</Text>
      <Text style={styles.meta}>Rating: {profile?.rating?.toFixed(2) ?? '—'} ⭐</Text>
      <Text style={styles.meta}>Status: {profile?.verificationStatus ?? 'pending'}</Text>

      <Pressable style={styles.signOut} onPress={signOut}>
        <Text style={styles.signOutText}>Sign out</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: theme.spacing.lg, backgroundColor: theme.colors.background },
  name: { fontSize: theme.fontSize.xxl, fontWeight: '700', color: theme.colors.text },
  meta: { color: theme.colors.textMuted, marginTop: theme.spacing.xs },
  signOut: { marginTop: theme.spacing.xl, padding: theme.spacing.md, alignItems: 'center', borderRadius: theme.radius.md, backgroundColor: theme.colors.surface },
  signOutText: { color: theme.colors.danger, fontWeight: '600' },
});