import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

import { api } from '../services/api';
import type { EarningsSummary } from '@mk-rides/shared-types';
import { theme } from '../theme';

/**
 * Driver earnings screen. Shows today's earnings, week-to-date, lifetime,
 * and a list of recent trips with fares and tips.
 */
export function EarningsScreen() {
  const [summary, setSummary] = useState<EarningsSummary | null>(null);

  useEffect(() => {
    api.driverEarnings().then(setSummary).catch(() => undefined);
  }, []);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>Today</Text>
      <Text style={styles.big}>KES {summary?.todayKsh?.toLocaleString() ?? '—'}</Text>

      <Text style={styles.heading}>This week</Text>
      <Text style={styles.medium}>KES {summary?.weekKsh?.toLocaleString() ?? '—'}</Text>

      <Text style={styles.heading}>Lifetime</Text>
      <Text style={styles.medium}>KES {summary?.lifetimeKsh?.toLocaleString() ?? '—'}</Text>

      <Text style={styles.heading}>Trips</Text>
      {summary?.recentTrips?.map((trip) => (
        <View key={trip.rideId} style={styles.trip}>
          <Text style={styles.tripTitle}>{trip.pickup} → {trip.dropoff}</Text>
          <Text style={styles.tripMeta}>
            {new Date(trip.completedAt).toLocaleString()} • KES {trip.fareKsh.toLocaleString()}
          </Text>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing.lg },
  heading: { color: theme.colors.textMuted, marginTop: theme.spacing.lg },
  big: { color: theme.colors.text, fontSize: theme.fontSize.display, fontWeight: '800' },
  medium: { color: theme.colors.text, fontSize: theme.fontSize.xl, fontWeight: '600' },
  trip: { paddingVertical: theme.spacing.sm, borderBottomColor: theme.colors.border, borderBottomWidth: 1 },
  tripTitle: { color: theme.colors.text, fontWeight: '600' },
  tripMeta: { color: theme.colors.textMuted, fontSize: theme.fontSize.sm },
});