import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { api } from '../services/api';
import { theme } from '../theme';
import type { DriverStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<DriverStackParamList, 'RideOffer'>;

/**
 * Incoming ride offer. The driver has 15 seconds to accept; otherwise
 * the offer is passed to the next eligible driver. Acceptance is final
 * within the timeout window.
 */
export function RideOfferScreen({ route, navigation }: Props) {
  const { rideId } = route.params;
  const [secondsLeft, setSecondsLeft] = useState(15);

  useEffect(() => {
    const t = setInterval(() => setSecondsLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, []);

  const handleAccept = async () => {
    try {
      await api.acceptRide(rideId);
      navigation.goBack();
    } catch {
      // surface error toast in a follow-up commit
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Ride offer</Text>
      <Text style={styles.timer}>{secondsLeft}s to respond</Text>
      <Text style={styles.body}>Ride ID: {rideId}</Text>

      <View style={styles.row}>
        <Pressable style={[styles.button, styles.accept]} onPress={handleAccept}>
          <Text style={styles.buttonText}>Accept</Text>
        </Pressable>
        <Pressable style={[styles.button, styles.decline]} onPress={() => navigation.goBack()}>
          <Text style={styles.buttonText}>Decline</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: theme.spacing.lg, backgroundColor: theme.colors.background, justifyContent: 'center' },
  title: { fontSize: theme.fontSize.xxl, fontWeight: '700', color: theme.colors.text, textAlign: 'center' },
  timer: { textAlign: 'center', color: theme.colors.warning, marginTop: theme.spacing.sm, fontWeight: '600' },
  body: { textAlign: 'center', color: theme.colors.textMuted, marginTop: theme.spacing.lg },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginTop: theme.spacing.xl },
  button: { flex: 1, padding: theme.spacing.md, borderRadius: theme.radius.md, alignItems: 'center', marginHorizontal: theme.spacing.xs },
  accept: { backgroundColor: theme.colors.accent },
  decline: { backgroundColor: theme.colors.surface },
  buttonText: { fontWeight: '700', color: theme.colors.textInverse },
});