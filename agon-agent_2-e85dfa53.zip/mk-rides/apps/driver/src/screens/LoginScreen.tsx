import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, ActivityIndicator } from 'react-native';

import { useDriverStore } from '../store/driverStore';
import { theme } from '../theme';

/**
 * Driver login. Drivers authenticate with phone + OTP, then verify their
 * driver profile (license, PSV badge, vehicle details) before going online.
 * The verification flow is owned by the admin dashboard.
 */
export function LoginScreen() {
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [stage, setStage] = useState<'phone' | 'code'>('phone');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const requestOtp = useDriverStore((s) => s.requestOtp);
  const verifyOtp = useDriverStore((s) => s.verifyOtp);

  const handleRequest = async () => {
    setError(null);
    setLoading(true);
    try {
      await requestOtp(phone);
      setStage('code');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send code');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setError(null);
    setLoading(true);
    try {
      await verifyOtp(phone, code);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid code');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>MK RIDES Driver</Text>

      {stage === 'phone' ? (
        <>
          <TextInput
            style={styles.input}
            placeholder="Phone (e.g. 0712 345 678)"
            keyboardType="phone-pad"
            value={phone}
            onChangeText={setPhone}
            autoComplete="tel"
          />
          <Pressable style={styles.button} onPress={handleRequest} disabled={phone.length < 9 || loading}>
            {loading ? <ActivityIndicator color="#0F172A" /> : <Text style={styles.buttonText}>Send code</Text>}
          </Pressable>
        </>
      ) : (
        <>
          <TextInput
            style={styles.input}
            placeholder="6-digit code"
            keyboardType="number-pad"
            value={code}
            onChangeText={setCode}
            maxLength={6}
          />
          <Pressable style={styles.button} onPress={handleVerify} disabled={code.length !== 6 || loading}>
            {loading ? <ActivityIndicator color="#0F172A" /> : <Text style={styles.buttonText}>Verify</Text>}
          </Pressable>
        </>
      )}

      {error && <Text style={styles.error}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: theme.spacing.xl, backgroundColor: theme.colors.background, justifyContent: 'center' },
  title: { fontSize: theme.fontSize.display, fontWeight: '800', color: theme.colors.text, textAlign: 'center', marginBottom: theme.spacing.xl },
  input: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.radius.md,
    padding: theme.spacing.md,
    fontSize: theme.fontSize.md,
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  button: { backgroundColor: theme.colors.accent, padding: theme.spacing.md, borderRadius: theme.radius.md, alignItems: 'center' },
  buttonText: { color: theme.colors.textInverse, fontWeight: '700' },
  error: { color: theme.colors.danger, marginTop: theme.spacing.md, textAlign: 'center' },
});